package com.example.budget_finance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
