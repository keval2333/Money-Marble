import 'package:budget_finance/globle.dart';
import 'package:budget_finance/screen/bottombar_activity.dart';
import 'package:budget_finance/screen/calculator/animate.dart';
import 'package:budget_finance/screen/calculator/calculate.dart';
import 'package:budget_finance/screen/calculator/color_provider.dart';
import 'package:budget_finance/screen/calculator/colors.dart';
import 'package:budget_finance/screen/calculator/record.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';
import 'package:path_provider/path_provider.dart';

void main() async {(SystemUiOverlayStyle( 
      statusBarColor: Colors.black, statusBarIconBrightness: Brightness.light));
  SystemChrome.setSystemUIOverlayStyle;
  WidgetsFlutterBinding.ensureInitialized();
  await _initializeHive();

  runApp( 
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => Calculate()),
        ChangeNotifierProvider(create: (_) => Animate()),
        ChangeNotifierProvider(create: (_) => ColorProvider()),
      ],
      child: Budgetfinance(),
    ),
  );
}

_initializeHive() async {
  final appDirectory = await getApplicationDocumentsDirectory();
  Hive.init(appDirectory.path);
  Hive.registerAdapter<Record>(RecordAdapter());
  await Hive.openBox<Record>(boxRecord);
  final box = await Hive.openBox(boxColor);
  if (box.length == 0) {
    print('Initialize Default Color Value');
    box.put('primary', AppColors.primary.value);
  }
}

class Budgetfinance extends StatefulWidget {
  Budgetfinance({Key key}) : super(key: key);

  @override
  _BudgetfinanceState createState() => _BudgetfinanceState();
}

class _BudgetfinanceState extends State<Budgetfinance> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
    return Sizer(builder: (context, orientation, devicetype) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
            fontFamily: 'VarelaRound',
            textSelectionTheme: TextSelectionThemeData(
              cursorColor: cc,
              selectionColor: cc,
              selectionHandleColor: cc,
            ),
            primaryColor: cc,
            primarySwatch: Colors.yellow,
            accentColor: cc,
            cursorColor: cc,
            indicatorColor: cc),
        home: Scaffold(body: Bottombar()),
      );
    });
  }
}
