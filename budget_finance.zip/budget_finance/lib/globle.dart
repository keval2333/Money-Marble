import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

var heading = 15.sp;
var title = 13.sp;
var text = 11.sp;
// Color yellow;
var c = "0xffFCC139";
Color cc;

Color yellow = Color(0xffFCC139);
// Color yellow = Color(0xffcfead9);67b9d1,

changecolor() {
  return c;
}

String colorr;

var tipstitle = 
["""Record your expenses""",
"""Budget for savings
""",
"""Find ways you can cut your spending
""",
"""Set savings goals
""",
"""Decide on your priorities
"""];


var tipsdesc = 
["""The first step to start saving money is to figure out how much you spend. Keep track of all your expenses—that means every coffee, household item and cash tip.

Once you have your data, organize the numbers by categories, such as gas, groceries and mortgage, and total each amount. Use your credit card and bank statements to make sure you’re accurate—and don’t forget any.

Tip: Look for a free spending tracker to help you get started. Choosing a digital program or app can help automate some of this work. Bank of America clients can use the Spending & Budgeting tool, which automatically categorizes your transactions for easier budgeting in the mobile app or online.""",
""" Once you have an idea of what you spend in a month, you can begin to organize your recorded expenses into a workable budget. Your budget should outline how your expenses measure up to your income—so you can plan your spending and limit overspending. Be sure to factor in expenses that occur regularly but not every month, such as car maintenance.

Tip: Include a savings category—aim to save 10 to 15 percent of your income.""",
"""If your expenses are so high that you can’t save as much as you’d like, it might be time to cut back. Identify nonessentials that you can spend less on, such as entertainment and dining out. Look for ways to save on your fixed monthly expenses like television and your cell phone, too.

Here are some ideas for trimming everyday expenses:

Use resources such as community event listings to find free or low-cost events to reduce entertainment spending.
Cancel subscriptions and memberships you don’t use—especially if they renew automatically.
Commit to eating out only once a month and trying places that fall into the “cheap eats” category.
Give yourself a “cooling off period”: When tempted by a nonessential purchase, wait a few days. You may be glad you passed—or ready to save up for it. """,
""" One of the best ways to save money is to set a goal. Start by thinking of what you might want to save for—perhaps you’re getting married, planning a vacation or saving for retirement. Then figure out how much money you’ll need and how long it might take you to save it. If you’re saving for retirement or your child’s education, consider putting that money into an investment account such as an IRA or 529 plan. While investments come with risks and can lose money, they also create the opportunity for growth when the market grows, and could be appropriate if you plan for an event far in advance. See step No. 6 for more details.""",
""" After your expenses and income, your goals are likely to have the biggest impact on how you allocate your savings. Be sure to remember long-term goals—it’s important that planning for retirement doesn’t take a back seat to shorter-term needs.

Tip: Learn how to prioritize your savings goals so you have a clear idea of where to start saving. For example, if you know you’re going to need to replace your car in the near future, you could start putting money away for one now."""];