import 'package:budget_finance/globle.dart';
import 'package:budget_finance/screen/home_activity.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

// color change code

 //class banavo will pop thi home ma lavo

class Changecolor extends StatefulWidget {
  Changecolor({Key key}) : super(key: key);

  @override
  _ChangecolorState createState() => _ChangecolorState();
}

class _ChangecolorState extends State<Changecolor> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        Navigator.push(context, Pageanimated(Home()));
      },
      child: Scaffold(
          body: Container(
          
        padding: EdgeInsets.fromLTRB(30, 50, 30, 0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    snackBar("Selected !!", context);
                    setState(() {
                      c = "0xffFCC139";
                    });
                    Navigator.push(context, Pageanimated(Home()));
                  },
                  child: Container(height: 70, width: 70, color: Color(0xffFCC139)),
                ),
                InkWell(
                  onTap: () {
                    snackBar("Selected !!", context);
                    setState(() {
                      c = "0xff67b9d1";
                    });
                    Navigator.push(context, Pageanimated(Home()));

                  },
                  child: Container(height: 70, width: 70, color: Color(0xff67b9d1)),
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                        snackBar("Selected !!", context);
                      c = "0xffcfead9";
                    });
                    Navigator.push(context, Pageanimated(Home()));

                  },
                  child: Container(height: 70, width: 70, color: Color(0xffcfead9)),
                ),
                InkWell(
                  onTap: () {
                    snackBar("Selected !!", context);
                    setState(() {
                      c = "0xffFFC0CB";
                    });
                    Navigator.push(context, Pageanimated(Home()));


                  },
                  child: Container(height: 70, width: 70, color: Color(0xffFFC0CB)),
                ),
              ],
            ),

            SizedBox(height: 20,),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    snackBar("Selected !!", context);
                    setState(() {
                      c = "0xfffc1703";
                    });
                    Navigator.push(context, Pageanimated(Home()));
                  },
                  child: Container(height: 70, width: 70, color: Color(0xfffc1703)),
                ),
                InkWell(
                  onTap: () {
                    snackBar("Selected !!", context);
                    setState(() {
                      c = "0xff57f249";
                    });
                    Navigator.push(context, Pageanimated(Home()));

                  },
                  child: Container(height: 70, width: 70, color: Color(0xff57f249)),
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                        snackBar("Selected !!", context);
                      c = "0xff49f2bd";
                    });
                    Navigator.push(context, Pageanimated(Home()));

                  },
                  child: Container(height: 70, width: 70, color: Color(0xff49f2bd)),
                ),
                InkWell(
                  onTap: () {
                    snackBar("Selected !!", context);
                    setState(() {
                      c = "0xff4965f2";
                    });
                    Navigator.push(context, Pageanimated(Home()));


                  },
                  child: Container(height: 70, width: 70, color: Color(0xff4965f2)),
                ),
              ],
            ),
          ],
        ),
      )),
    );
  }
}
  
// home na int ma mukvo


   
  
//color: yellow ni jgya a replace
 







