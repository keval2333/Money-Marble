import 'dart:ui';
import 'package:age/age.dart';
import 'package:budget_finance/globle.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class Interestcalculation extends StatefulWidget {
  Interestcalculation({Key key}) : super(key: key);

  @override
  _InterestcalculationState createState() => _InterestcalculationState();
}

class _InterestcalculationState extends State<Interestcalculation> {
  double day = 0, month, year;
  int dayy=0,monthh=0,yearr=0;
  var frmkey1 = GlobalKey<FormState>();
  TextEditingController netvalue = new TextEditingController(text: "0");
  var frmkey2 = GlobalKey<FormState>();
  TextEditingController interestvalue = new TextEditingController(text: "0.0");
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          child: SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 7.h,
                  ),
                  Container(
                    child: Text(
                      'Calculate \nInterest',
                      style: TextStyle(
                        fontSize: heading,
                        height: 1.4,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 5.h,
                  ),
                  Form(
                      key: frmkey1,
                      child: TextFormField(
                        cursorColor: yellow,
                        controller: netvalue,
                        keyboardType: TextInputType.number,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: text,
                        ),
                        //ignore: missing_return
                        validator: (value) {
                          if (value.isEmpty) {
                            return snackBar("Enter Number", context);
                          } else {}
                        },
                        cursorHeight: 30,
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: yellow),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: yellow),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                          border: OutlineInputBorder(
                              borderSide: BorderSide(color: yellow)),
                          labelText: 'Enter principal amount',
                          labelStyle: TextStyle(
                              fontSize: MediaQuery.of(context).size.height / 70,
                              color: Colors.black),
                        ),
                      )),
                  SizedBox(
                    height: 3.h,
                  ),
                  Form(
                      key: frmkey2,
                      child: TextFormField(
                        cursorColor: yellow,
                        controller: interestvalue,
                        keyboardType: TextInputType.number,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: text,
                        ),
                        // ignore: missing_return
                        validator: (value) {
                          if (value.isEmpty) {
                            return snackBar("Enter Number", context);
                          } else {}
                        },
                        cursorHeight: 30,
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: yellow),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: yellow),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                          border: OutlineInputBorder(
                              borderSide: BorderSide(color: yellow)),
                          labelText: 'Enter percentage',
                          labelStyle: TextStyle(
                              fontSize: MediaQuery.of(context).size.height / 70,
                              color: Colors.black),
                        ),
                      )),
                  SizedBox(
                    height: 3.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: InkWell(
                          onTap: () {
                            month = (double.parse(netvalue.text.toString()) *
                                double.parse(interestvalue.text.toString())/100);
                            year = ((double.parse(netvalue.text.toString()) *
                                double.parse(interestvalue.text.toString())/100)*12);
                            day = ((double.parse(netvalue.text.toString()) *
                                double.parse(interestvalue.text.toString())/100)/30);
                            setState(() {
                              monthh=month.round();
                              yearr=year.round();
                              dayy=day.round();
                            });
                            if(netvalue.text=="0" || interestvalue.text=="0")
                            {
                              snackBar('Enter amount', context);
                            }
                          },
                          child: expandedbtn('Calculate'),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: InkWell(
                          onTap: () {
                            interestvalue.text="0";
                            netvalue.text="0";
                          },
                          child: expandedbtn('Reset'),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 3.h,
                  ),
                  headingtext('Interest Chart'),
                  SizedBox(
                    height: 3.h,
                  ),
                  Row(
                    children: [
                      agebtn("Per Day", dayy.toString()),
                      SizedBox(
                        width: 5,
                      ),
                      agebtn("Per Month",monthh.toString()),
                      SizedBox(
                        width: 5,
                      ),
                      agebtn("Per Year", yearr.toString())
                    ],
                  ),
                  SizedBox(
                    height: 3.h,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  getdata1() {
    final checkfrm1 = frmkey1.currentState.validate();
    if (!checkfrm1) {
      return true;
    }
    frmkey1.currentState.save();
    return false;
  }

  getdata2() {
    final checkfrm2 = frmkey1.currentState.validate();
    if (!checkfrm2) {
      return true;
    }
    frmkey2.currentState.save();
    return false;
  }
}
