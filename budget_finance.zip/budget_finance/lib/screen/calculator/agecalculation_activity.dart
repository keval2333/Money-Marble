import 'dart:ui';
import 'package:age/age.dart';
import 'package:budget_finance/globle.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class Agecalculation extends StatefulWidget {
  Agecalculation({Key key}) : super(key: key);

  @override
  _AgecalculationState createState() => _AgecalculationState();
}

class _AgecalculationState extends State<Agecalculation> {
  double year = 0.0, month = 0, weak = 0, diffmonth = 0;
  int day = 0, minute = 0, hour = 0, birthday = 0, diffday = 0;
  DateTime birth, curbirthday;
  DateTime dt = DateTime.now();
  DateTime now = DateTime.now();
  AgeDuration nextBirthdayDuration;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          child: SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 7.h,
                  ),
                  Container(
                    child: Text(
                      'Calculate Your\nAge',
                      style: TextStyle(
                        fontSize: heading,
                        height: 1.4,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 5.h,
                  ),
                  Container(
                    alignment: Alignment.center,
                    child: InkWell(
                      onTap: () {
                        selectdate(context);
                      },
                      child: Container(
                          alignment: Alignment.center,
                          width: 90.w,
                          height: 8.h,
                          decoration: BoxDecoration(
                              border: Border.all(color: yellow, width: 1),
                              borderRadius: BorderRadius.circular(5)),
                          child: Text("${dt.day}-${dt.month}-${dt.year}",
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: heading))),
                    ),
                  ),
                  SizedBox(
                    height: 3.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: InkWell(
                          onTap: () {
                            final birthday =
                                DateTime(dt.year, dt.month, dt.day);
                            final date2 = DateTime.now();
                            curbirthday =
                                DateTime(date2.year, dt.month, dt.day);
                            var bb = dt.add(const Duration(days: 365));
                            setState(() {
                              birth = bb;
                              year = (date2.difference(birthday).inDays) / 365;
                              month =
                                  ((date2.difference(birthday).inDays) / 365) *
                                      12;
                              weak = (date2.difference(birthday).inDays) / 7;
                              day = date2.difference(birthday).inDays;
                              minute =
                                  (date2.difference(birthday).inMinutes - 16);
                              hour = ((date2.difference(birthday).inDays) * 24);
                              diffday = curbirthday.difference(date2).inDays;
                              diffmonth =
                                  ((curbirthday.difference(date2).inDays) /
                                          365) *
                                      12;
                              DateTime tempDate = DateTime(
                                  date2.year, birthday.month, birthday.day);
                              DateTime nextBirthdayDate =
                                  tempDate.isBefore(date2)
                                      ? Age.add(
                                          date: tempDate,
                                          duration: AgeDuration(years: 1))
                                      : tempDate;

                              nextBirthdayDuration = Age.dateDifference(
                                  fromDate: date2, toDate: nextBirthdayDate);
                              print("next${nextBirthdayDuration.toString()}");
                            });
                          },
                          child: expandedbtn('Calculate'),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: InkWell(
                          onTap: () {
                            selectdate(context);
                          },
                          child: expandedbtn('Reset'),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 3.h,
                  ),
                  headingtext('Age Chart'),
                  SizedBox(
                    height: 3.h,
                  ),
                  Row(
                    children: [
                      agebtn('Year', year.toString().split(".")[0]),
                      SizedBox(
                        width: 5,
                      ),
                      agebtn('Month', month.toString().split(".")[0]),
                      SizedBox(
                        width: 5,
                      ),
                      agebtn('Weak', weak.toString().split(".")[0])
                    ],
                  ),
                  SizedBox(
                    height: 3.h,
                  ),
                  Row(
                    children: [
                      agebtn('Day', day.toString().split(".")[0]),
                      SizedBox(
                        width: 5,
                      ),
                      agebtn('Hours', hour.toString().split(".")[0]),
                      SizedBox(
                        width: 5,
                      ),
                      agebtn('Minute', minute.toString().split(".")[0])
                    ],
                  ),
                  SizedBox(
                    height: 3.h,
                  ),
                  headingtext('Your next birthday'),
                  SizedBox(
                    height: 3.h,
                  ),
                  Container(
                    alignment: Alignment.center,
                    height: 7.h,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        color: Colors.grey[200]),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          child: nextBirthdayDuration !=  null ?
                           Text(
                            " Left ${nextBirthdayDuration.toString().split(",")[1]} ${nextBirthdayDuration.toString().split(",")[2]}",
                            style: TextStyle(fontSize: title),
                          ):
                          Text("Enter birthdate")
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  selectdate(BuildContext context) async {
    final DateTime pick = await showDatePicker(
      context: context,
      initialDate: dt,
      firstDate: DateTime(1800),
      lastDate: DateTime.now(),
      initialEntryMode: DatePickerEntryMode.calendar,
      initialDatePickerMode: DatePickerMode.year,
      helpText: 'Select Birthday Date',
      cancelText: 'Cancle',
      confirmText: 'Ok',
      errorFormatText: 'Error',
      errorInvalidText: 'Wrong',
      fieldHintText: 'Select date',
      fieldLabelText: 'Enter Date',
    );
    if (pick != null && pick != dt) {
      setState(() {
        dt = pick;
      });
    }
  }
}
