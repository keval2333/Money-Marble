import 'package:budget_finance/screen/calculator/dimensions.dart';
import 'package:budget_finance/screen/calculator/record.dart';
import 'package:budget_finance/screen/calculator/record_container.dart';
import 'package:budget_finance/screen/calculator/utilities.dart';
import 'package:flutter/material.dart';

class RecordListBuilder extends StatelessWidget {
  final box;

  RecordListBuilder({@required this.box});

  @override
  Widget build(BuildContext context) {
    List<Record> _recordList = getReversedList(box: box);
    return Expanded(
      child: ListView.separated(
        physics: BouncingScrollPhysics(),
        padding: EdgeInsets.all(appPadding),
        itemCount: _recordList.length,
        separatorBuilder: (_, index) => SizedBox(height: 24.0),
        itemBuilder: (_, index) {
          final Record record = _recordList[index];
          return RecordContainer(record: record);
        },
      ),
    );
  }
}
