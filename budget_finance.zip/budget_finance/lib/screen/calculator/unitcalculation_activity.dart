import 'package:budget_finance/globle.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class Unitcalculation extends StatefulWidget {
  Unitcalculation({Key key}) : super(key: key);

  @override
  _UnitcalculationState createState() => _UnitcalculationState();
}

class _UnitcalculationState extends State<Unitcalculation> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          child: SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 7.h,
                  ),
                  Container(
                    child: Text(
                      'Calculate \nUnit',
                      style: TextStyle(
                        fontSize: heading,
                        height: 1.4,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 3.h,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(context, Pageanimated(Lengthcal()));
                    },
                    child: Container(
                        alignment: Alignment.center,
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: Colors.grey[200]),
                        child: Column(
                          children: [
                            headingtext('Length calculation'),
                            SizedBox(
                              height: 2.h,
                            ),
                            Container(
                              child: Container(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  'Kilometer, Meter, Centimeter, Milimeter, Micrometer, Nanometer, Mile, Yard, foot, Inch',
                                  style: TextStyle(
                                      fontSize: text, color: Colors.black),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 2.h,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Container(
                                    decoration: BoxDecoration(
                                        color: yellow,
                                        borderRadius: BorderRadius.circular(5)),
                                    padding: EdgeInsets.all(7),
                                    child: Text(
                                      'Calculate now',
                                      style: TextStyle(fontSize: 10.sp),
                                    )),
                              ],
                            )
                          ],
                        )),
                  ),
                  SizedBox(height: 5),
                  Divider(
                    color: Colors.grey,
                  ),
                  SizedBox(height: 5),
                  InkWell(
                    onTap: () {
                      Navigator.push(context, Pageanimated(Masscal()));
                    },
                    child: Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: Colors.grey[200]),
                      child: Column(
                        children: [
                          headingtext('Mass calculation'),
                          SizedBox(
                            height: 2.h,
                          ),
                          Container(
                            child: Container(
                              alignment: Alignment.topLeft,
                              child: Text(
                                'Gram, Kilogram, Milligram, Hectogram, Nanogram, Stone',
                                style: TextStyle(
                                    fontSize: text, color: Colors.black),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 2.h,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                  decoration: BoxDecoration(
                                      color: yellow,
                                      borderRadius: BorderRadius.circular(5)),
                                  padding: EdgeInsets.all(7),
                                  child: Text(
                                    'Calculate now',
                                    style: TextStyle(fontSize: 10.sp),
                                  )),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 5),
                  Divider(
                    color: Colors.grey,
                  ),
                  SizedBox(height: 5),
                  InkWell(
                    onTap: () {
                      Navigator.push(context, Pageanimated(Bytecal()));
                    },
                    child: Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: Colors.grey[200]),
                      child: Column(
                        children: [
                          headingtext('Byte calculation'),
                          SizedBox(
                            height: 2.h,
                          ),
                          Container(
                            child: Container(
                              alignment: Alignment.topLeft,
                              child: Text(
                                'Bits, Byte, Kilobit, Megabit, Gigabit, Petabit, Exabit',
                                style: TextStyle(
                                    fontSize: text, color: Colors.black),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 2.h,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                  decoration: BoxDecoration(
                                      color: yellow,
                                      borderRadius: BorderRadius.circular(5)),
                                  padding: EdgeInsets.all(7),
                                  child: Text(
                                    'Calculate now',
                                    style: TextStyle(fontSize: 10.sp),
                                  )),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 5),
                  Divider(
                    color: Colors.grey,
                  ),
                  SizedBox(height: 5),
                  InkWell(
                    onTap: () {
                      Navigator.push(context, Pageanimated(Powercal()));
                    },
                    child: Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: Colors.grey[200]),
                      child: Column(
                        children: [
                          headingtext('Power calculation'),
                          SizedBox(
                            height: 2.h,
                          ),
                          Container(
                            child: Container(
                              alignment: Alignment.topLeft,
                              child: Text(
                                'Watts, hourspowers, Kilowatts, Megawatts,',
                                style: TextStyle(
                                    fontSize: text, color: Colors.black),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 2.h,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                  decoration: BoxDecoration(
                                      color: yellow,
                                      borderRadius: BorderRadius.circular(5)),
                                  padding: EdgeInsets.all(7),
                                  child: Text(
                                    'Calculate now',
                                    style: TextStyle(fontSize: 10.sp),
                                  )),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 5),
                  Divider(
                    color: Colors.grey,
                  ),
                  SizedBox(height: 5),
                  InkWell(
                    onTap: () {
                            Navigator.push(context, Pageanimated(Timecal()));
                          },
                    child: Container(
                      alignment: Alignment.center,
                            padding: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                color: Colors.grey[200]),
                      child: Column(
                        children: [
                          headingtext('Time calculation'),
                          SizedBox(
                            height: 2.h,
                          ),
                          Container(
                            
                            child: Container(
                              alignment: Alignment.topLeft,
                              child: Text(
                                'Day, Centuries, Hours, Month, Weak, Year',
                                style: TextStyle(
                                    fontSize: text, color: Colors.black),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 2.h,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                  decoration: BoxDecoration(
                                      color: yellow,
                                      borderRadius: BorderRadius.circular(5)),
                                  padding: EdgeInsets.all(7),
                                  child: Text(
                                    'Calculate now',
                                    style: TextStyle(fontSize: 10.sp),
                                  )),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 3.h,
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// Length calculation

class Lengthcal extends StatefulWidget {
  Lengthcal({Key key}) : super(key: key);

  @override
  _LengthcalState createState() => _LengthcalState();
}

class _LengthcalState extends State<Lengthcal> {
  double km = 0,
      meter = 0,
      cm = 0,
      mm = 0,
      mc = 0,
      nm = 0,
      mile = 0,
      yard = 0,
      ft = 0,
      inch = 0;
  String _chosenValue;
  var frmkey1 = GlobalKey<FormState>();
  TextEditingController length = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          child: Container(
            padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 7.h,
                ),
                Container(
                  child: Text(
                    'Calculate \nLength',
                    style: TextStyle(
                      fontSize: heading,
                      height: 1.4,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  padding:
                      EdgeInsets.only(left: 5, top: 13, bottom: 13, right: 5),
                  width: 100.h,
                  decoration: BoxDecoration(
                      border: Border.all(color: yellow),
                      borderRadius: BorderRadius.circular(5)),
                  child: DropdownButtonFormField<String>(
                    isExpanded: true,
                    focusColor: Colors.white,
                    decoration: InputDecoration.collapsed(hintText: ''),
                    value: _chosenValue,
                    //elevation: 5,
                    style: TextStyle(color: Colors.white),
                    iconEnabledColor: Colors.black,
                    items: <String>[
                      'Kilometer',
                      'Meter',
                      'Centimeter',
                      'Milimeter',
                      'Micrometer',
                      'Nanometer',
                      'Mile',
                      'Yard',
                      'Foot',
                      'Inch'
                    ].map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Container(
                          width: 80.w,
                          child: Text(
                            value,
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                      );
                    }).toList(),
                    hint: Text(
                      "-----Select Length-----",
                      style: TextStyle(color: Colors.black, fontSize: 10.sp),
                    ),
                    onChanged: (String value) {
                      setState(() {
                        _chosenValue = value;
                      });
                    },
                  ),
                ),
                SizedBox(
                  height: 5.h,
                ),
                Form(
                    key: frmkey1,
                    child: TextFormField(
                      cursorColor: yellow,
                      controller: length,
                      keyboardType: TextInputType.number,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: text,
                      ),
                      //ignore: missing_return
                      validator: (value) {
                        if (value.isEmpty) {
                          return snackBar("Enter lenght", context);
                        } else {}
                      },
                      cursorHeight: 30,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: yellow)),
                        labelText: 'Enter kilometer',
                        labelStyle: TextStyle(
                            fontSize: MediaQuery.of(context).size.height / 70,
                            color: Colors.black),
                      ),
                    )),
                SizedBox(
                  height: 3.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          FocusScope.of(context).requestFocus(FocusNode());
                          setState(() {
                            km = double.parse(length.text);
                            meter = (double.parse(length.text) * 1000);
                            cm = (double.parse(length.text) * 100000);
                            mm = (double.parse(length.text) * 1000000);
                            mc = (double.parse(length.text) * 1000000000);
                            nm = (double.parse(length.text) * 1000000000000);
                            mile = (double.parse(length.text) * 0.62);
                            mile = double.parse(mile.toStringAsFixed(2));
                            yard = (double.parse(length.text) * 1093.61);
                            yard = double.parse(yard.toStringAsFixed(2));
                            ft = (double.parse(length.text) * 3280.84);
                            ft = double.parse(ft.toStringAsFixed(2));
                            inch = (double.parse(length.text) * 39370);
                          });
                        },
                        child: expandedbtn('Calculate'),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          length.text="0";
                        },
                        child: expandedbtn('Reset'),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                  ],
                ),
                SizedBox(
                  height: 3.h,
                ),
                headingtext('Length Chart'),
                SizedBox(
                  height: 3.h,
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            callength("Kilometer", km.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Meter", meter.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Inch", inch.toString()),
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        Row(
                          children: [
                            callength("Mile", mile.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Yard", yard.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Foot", ft.toString())
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        Row(
                          children: [
                            callength("Centimeter", cm.toString()),
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        Row(
                          children: [
                            callength("Milimeter", mm.toString()),
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        Row(
                          children: [
                            callength("Micrometer", mc.toString()),
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        Row(
                          children: [
                            callength("Nanometer", nm.toString()),
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Mass calculation

class Masscal extends StatefulWidget {
  Masscal({Key key}) : super(key: key);

  @override
  _MasscalState createState() => _MasscalState();
}

class _MasscalState extends State<Masscal> {
  double gm = 0, kg = 0, mg = 0, stone = 0, hg = 0, ng = 0;
  String _chosenValue;
  var frmkey1 = GlobalKey<FormState>();
  TextEditingController length = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          child: Container(
            padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 7.h,
                ),
                Container(
                  child: Text(
                    'Calculate \nMass',
                    style: TextStyle(
                      fontSize: heading,
                      height: 1.4,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  padding:
                      EdgeInsets.only(left: 5, top: 13, bottom: 13, right: 5),
                  width: 100.h,
                  decoration: BoxDecoration(
                      border: Border.all(color: yellow),
                      borderRadius: BorderRadius.circular(5)),
                  child: DropdownButtonFormField<String>(
                    isExpanded: true,
                    focusColor: Colors.white,
                    decoration: InputDecoration.collapsed(hintText: ''),
                    value: _chosenValue,
                    //elevation: 5,
                    style: TextStyle(color: Colors.white),
                    iconEnabledColor: Colors.black,
                    items: <String>[
                      'Grams',
                      'Kilograms',
                      'Miligrams',
                      'Stones',
                      'Hectograms',
                      'Nanograms',
                    ].map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Container(
                          width: 80.w,
                          child: Text(
                            value,
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                      );
                    }).toList(),
                    hint: Text(
                      "-----Select Mass-----",
                      style: TextStyle(color: Colors.black, fontSize: 10.sp),
                    ),
                    onChanged: (String value) {
                      setState(() {
                        _chosenValue = value;
                      });
                    },
                  ),
                ),
                SizedBox(
                  height: 5.h,
                ),
                Form(
                    key: frmkey1,
                    child: TextFormField(
                      cursorColor: yellow,
                      controller: length,
                      keyboardType: TextInputType.number,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: text,
                      ),
                      //ignore: missing_return
                      validator: (value) {
                        if (value.isEmpty) {
                          return snackBar("Enter Mass", context);
                        } else {}
                      },
                      cursorHeight: 30,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: yellow)),
                        labelText: 'Enter grams',
                        labelStyle: TextStyle(
                            fontSize: MediaQuery.of(context).size.height / 70,
                            color: Colors.black),
                      ),
                    )),
                SizedBox(
                  height: 3.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          FocusScope.of(context).requestFocus(FocusNode());
                          setState(() {
                            gm = double.parse(length.text);
                            kg = (double.parse(length.text) * 0.001);
                            mg = (double.parse(length.text) * 1000);
                            stone = (double.parse(length.text) * 0.00016);
                            hg = (double.parse(length.text) * 0.01);
                            ng = (double.parse(length.text) * 1000000000);
                          });
                        },
                        child: expandedbtn('Calculate'),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          length.text="0";
                        },
                        child: expandedbtn('Reset'),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                  ],
                ),
                SizedBox(
                  height: 3.h,
                ),
                headingtext('Mass Chart'),
                SizedBox(
                  height: 3.h,
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            callength("Grams", gm.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Kilograms", kg.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Miligrams", mg.toString()),
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        Row(
                          children: [
                            callength("Stones", stone.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Hectograms", hg.toString()),
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        Row(
                          children: [callength("Nanograms", ng.toString())],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Byte calculation

class Bytecal extends StatefulWidget {
  Bytecal({Key key}) : super(key: key);

  @override
  _BytecalState createState() => _BytecalState();
}

class _BytecalState extends State<Bytecal> {
  double byte = 0,
      kilobyte = 0,
      megabyte = 0,
      gigabyte = 0,
      terabyte = 0,
      petabyte = 0,
      bit = 0,
      kilobit = 0,
      megabit = 0,
      gigabit = 0,
      terabit = 0,
      petabit = 0;
  String _chosenValue;
  var frmkey1 = GlobalKey<FormState>();
  TextEditingController length = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          child: Container(
            padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 7.h,
                ),
                Container(
                  child: Text(
                    'Calculate \nByte',
                    style: TextStyle(
                      fontSize: heading,
                      height: 1.4,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  padding:
                      EdgeInsets.only(left: 5, top: 13, bottom: 13, right: 5),
                  width: 100.h,
                  decoration: BoxDecoration(
                      border: Border.all(color: yellow),
                      borderRadius: BorderRadius.circular(5)),
                  child: DropdownButtonFormField<String>(
                    isExpanded: true,
                    focusColor: Colors.white,
                    decoration: InputDecoration.collapsed(hintText: ''),
                    value: _chosenValue,
                    //elevation: 5,
                    style: TextStyle(color: Colors.white),
                    iconEnabledColor: Colors.black,
                    items: <String>[
                      'Byte',
                      'Kilobyte',
                      'Megabyte',
                      // 'Gigabyte',
                      // 'Terabyte',
                      // 'Petabyte',
                      'Bit',
                      'Kilobit',
                      'Megabit',
                      // 'Gigabit',
                      // 'Terabit',
                      // 'Petabit',
                    ].map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Container(
                          width: 80.w,
                          child: Text(
                            value,
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                      );
                    }).toList(),
                    hint: Text(
                      "-----Select Byte-----",
                      style: TextStyle(color: Colors.black, fontSize: 10.sp),
                    ),
                    onChanged: (String value) {
                      setState(() {
                        _chosenValue = value;
                      });
                    },
                  ),
                ),
                SizedBox(
                  height: 5.h,
                ),
                Form(
                    key: frmkey1,
                    child: TextFormField(
                      cursorColor: yellow,
                      controller: length,
                      keyboardType: TextInputType.number,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: text,
                      ),
                      //ignore: missing_return
                      validator: (value) {
                        if (value.isEmpty) {
                          return snackBar("Enter byte", context);
                        } else {}
                      },
                      cursorHeight: 30,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: yellow)),
                        labelText: 'Enter byte',
                        labelStyle: TextStyle(
                            fontSize: MediaQuery.of(context).size.height / 70,
                            color: Colors.black),
                      ),
                    )),
                SizedBox(
                  height: 3.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          FocusScope.of(context).requestFocus(FocusNode());
                          setState(() {
                            byte = double.parse(length.text);
                            kilobyte = (double.parse(length.text) * 0.001);
                            megabyte = (double.parse(length.text) * 0.0000001);

                            bit = (double.parse(length.text) * 8);
                            kilobit = (double.parse(length.text) / 125);
                            megabit = (double.parse(length.text) / 125000);
                          });
                        },
                        child: expandedbtn('Calculate'),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          length.text="0";
                        },
                        child: expandedbtn('Reset'),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                  ],
                ),
                SizedBox(
                  height: 3.h,
                ),
                headingtext('Byte Chart'),
                SizedBox(
                  height: 3.h,
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            callength("Byte", byte.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Kilobyte", kilobyte.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Megabyte", megabyte.toString()),
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        Row(
                          children: [
                            callength("Bit", bit.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Kilobit", kilobit.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Megabit", megabit.toString())
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        // Row(
                        //   children: [

                        //   ],
                        // ),
                        // SizedBox(
                        //   height: 3.h,
                        // ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Time Calculation
class Timecal extends StatefulWidget {
  Timecal({Key key}) : super(key: key);

  @override
  _TimecalState createState() => _TimecalState();
}

class _TimecalState extends State<Timecal> {
  double day = 0, cen = 0, hour = 0, month = 0, weak = 0, year = 0;
  String _chosenValue;
  var frmkey1 = GlobalKey<FormState>();
  TextEditingController length = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          child: Container(
            padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 7.h,
                ),
                Container(
                  child: Text(
                    'Calculate \nTime',
                    style: TextStyle(
                      fontSize: heading,
                      height: 1.4,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  padding:
                      EdgeInsets.only(left: 5, top: 13, bottom: 13, right: 5),
                  width: 100.h,
                  decoration: BoxDecoration(
                      border: Border.all(color: yellow),
                      borderRadius: BorderRadius.circular(5)),
                  child: DropdownButtonFormField<String>(
                    isExpanded: true,
                    focusColor: Colors.white,
                    decoration: InputDecoration.collapsed(hintText: ''),
                    value: _chosenValue,
                    //elevation: 5,
                    style: TextStyle(color: Colors.white),
                    iconEnabledColor: Colors.black,
                    items: <String>[
                      'Hours',
                      'Day',
                      'Weak',
                      'Month',
                      'Centuries',
                      'Year',
                    ].map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Container(
                          width: 80.w,
                          child: Text(
                            value,
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                      );
                    }).toList(),
                    hint: Text(
                      "-----Select Time-----",
                      style: TextStyle(color: Colors.black, fontSize: 10.sp),
                    ),
                    onChanged: (String value) {
                      setState(() {
                        _chosenValue = value;
                      });
                    },
                  ),
                ),
                SizedBox(
                  height: 5.h,
                ),
                Form(
                    key: frmkey1,
                    child: TextFormField(
                      cursorColor: yellow,
                      controller: length,
                      keyboardType: TextInputType.number,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: text,
                      ),
                      //ignore: missing_return
                      validator: (value) {
                        if (value.isEmpty) {
                          return snackBar("Enter day", context);
                        } else {}
                      },
                      cursorHeight: 30,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: yellow)),
                        labelText: 'Enter days',
                        labelStyle: TextStyle(
                            fontSize: MediaQuery.of(context).size.height / 70,
                            color: Colors.black),
                      ),
                    )),
                SizedBox(
                  height: 3.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          FocusScope.of(context).requestFocus(FocusNode());
                          setState(() {
                            day = double.parse(length.text);
                            hour = (double.parse(length.text) * 24);
                            weak = (double.parse(length.text) / 7);
                            weak = double.parse(weak.toStringAsFixed(2));
                            month = (double.parse(length.text) / 30);
                            month = double.parse(month.toStringAsFixed(2));
                            cen = (double.parse(length.text) / 100);
                            cen = double.parse(cen.toStringAsFixed(2));
                            year = (double.parse(length.text) / 365);
                            year = double.parse(year.toStringAsFixed(2));
                          });
                        },
                        child: expandedbtn('Calculate'),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          length.text="0";
                        },
                        child: expandedbtn('Reset'),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                  ],
                ),
                SizedBox(
                  height: 3.h,
                ),
                headingtext('Time Chart'),
                SizedBox(
                  height: 3.h,
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            callength("Days", day.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Hours", hour.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Weaks", weak.toString()),
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        Row(
                          children: [
                            callength("Months", month.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Centuries", cen.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Years", year.toString())
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        // Row(
                        //   children: [

                        //   ],
                        // ),
                        // SizedBox(
                        //   height: 3.h,
                        // ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Powercal converter

class Powercal extends StatefulWidget {
  Powercal({Key key}) : super(key: key);

  @override
  _PowercalState createState() => _PowercalState();
}

class _PowercalState extends State<Powercal> {
  double watts = 0, horse = 0, kw = 0, mw = 0;
  String _chosenValue;
  var frmkey1 = GlobalKey<FormState>();
  TextEditingController length = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          child: Container(
            padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 7.h,
                ),
                Container(
                  child: Text(
                    'Calculate \nPower',
                    style: TextStyle(
                      fontSize: heading,
                      height: 1.4,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  padding:
                      EdgeInsets.only(left: 5, top: 13, bottom: 13, right: 5),
                  width: 100.h,
                  decoration: BoxDecoration(
                      border: Border.all(color: yellow),
                      borderRadius: BorderRadius.circular(5)),
                  child: DropdownButtonFormField<String>(
                    isExpanded: true,
                    focusColor: Colors.white,
                    decoration: InputDecoration.collapsed(hintText: ''),
                    value: _chosenValue,
                    //elevation: 5,
                    style: TextStyle(color: Colors.white),
                    iconEnabledColor: Colors.black,
                    items: <String>[
                      'Watts',
                      'Horsepower',
                      'Kilowatts',
                      'Megawatts',
                    ].map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Container(
                          width: 80.w,
                          child: Text(
                            value,
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                      );
                    }).toList(),
                    hint: Text(
                      "-----Select Power-----",
                      style: TextStyle(color: Colors.black, fontSize: 10.sp),
                    ),
                    onChanged: (String value) {
                      setState(() {
                        _chosenValue = value;
                      });
                    },
                  ),
                ),
                SizedBox(
                  height: 5.h,
                ),
                Form(
                    key: frmkey1,
                    child: TextFormField(
                      cursorColor: yellow,
                      controller: length,
                      keyboardType: TextInputType.number,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: text,
                      ),
                      //ignore: missing_return
                      validator: (value) {
                        if (value.isEmpty) {
                          return snackBar("Enter watts", context);
                        } else {}
                      },
                      cursorHeight: 30,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: yellow)),
                        labelText: 'Enter watts',
                        labelStyle: TextStyle(
                            fontSize: MediaQuery.of(context).size.height / 70,
                            color: Colors.black),
                      ),
                    )),
                SizedBox(
                  height: 3.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          FocusScope.of(context).requestFocus(FocusNode());
                          setState(() {
                            watts = double.parse(length.text);
                            horse = (double.parse(length.text) * 0.001340);
                            kw = (double.parse(length.text) * 0.001);
                            mw = (double.parse(length.text) * 0.000001);
                          });
                        },
                        child: expandedbtn('Calculate'),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          length.text="0";
                        },
                        child: expandedbtn('Reset'),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                  ],
                ),
                SizedBox(
                  height: 3.h,
                ),
                headingtext('Power Chart'),
                SizedBox(
                  height: 3.h,
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            callength("Watts", watts.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Horse power", horse.toString()),
                            SizedBox(
                              width: 5,
                            ),
                            callength("Kilowatts", kw.toString()),
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        Row(
                          children: [
                            callength("Megawatts", mw.toString()),
                          ],
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
