// font size
const double sizeHeadline1 = 76.29;
const double sizeHeadline2 = 61.04;
const double sizeHeadline3 = 48.83;
const double sizeHeadline4 = 39.06;
const double sizeHeadline5 = 31.25;
const double sizeHeadline6 = 25.0;
const double sizeSubtitle1 = 20.0;
const double sizeSubtitle2 = 16.0;
const double sizeBody1 = 16.0;
const double sizeBody2 = 14.0;
const double sizeCaption = 12.80;

// padding
const double appPadding = 16.00;
