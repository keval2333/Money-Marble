import 'package:budget_finance/screen/calculator/custom_icon_button.dart';
import 'package:budget_finance/screen/calculator/record.dart';
import 'package:budget_finance/screen/calculator/utilities.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:line_awesome_icons/line_awesome_icons.dart';

class RecordAppbar extends StatelessWidget {
  final _recordBox = Hive.box<Record>(boxRecord);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        SizedBox(height: 25.0),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            CustomIconButton(
              icon: LineAwesomeIcons.arrow_left,
              onPressed: () => Navigator.pop(context),
            ),
            Text('Record History', style: appBarStyle(context)),
            CustomIconButton(
              icon: LineAwesomeIcons.trash,
              onPressed: () {
                _recordBox..clear();
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ],
    );
  }
}
