import 'package:budget_finance/globle.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class Managecrdrdatafetch extends StatefulWidget {
  Managecrdrdatafetch({Key key}) : super(key: key);

  @override
  _ManagecrdrdatafetchState createState() => _ManagecrdrdatafetchState();
}

class _ManagecrdrdatafetchState extends State<Managecrdrdatafetch> {
  var frmkey1 = GlobalKey<FormState>();
  String _chosenValue;
  TextEditingController name = new TextEditingController();
  TextEditingController mobile = new TextEditingController();
  TextEditingController refername = new TextEditingController();
  TextEditingController refermobile = new TextEditingController();
  TextEditingController amount = new TextEditingController();
  TextEditingController caption = new TextEditingController();
  DateTime dt = DateTime.now();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          child: SingleChildScrollView(
          padding: EdgeInsets.all(10),
          child: Form(
            key: frmkey1,
            child: Column(
              children: [
                SizedBox(
                  height: 6.h,
                ),
                headingtext('Credit Debit Transection'),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  padding:
                      EdgeInsets.only(left: 5, top: 13, bottom: 13, right: 5),
                  width: 100.h,
                  decoration: BoxDecoration(
                      border: Border.all(color: yellow),
                      borderRadius: BorderRadius.circular(5)),
                  child: DropdownButtonFormField<String>(
                    isExpanded: true,
                    focusColor: Colors.white,
                    decoration: InputDecoration.collapsed(hintText: ''),
                    value: _chosenValue,
                    //elevation: 5,
                    style: TextStyle(color: Colors.white),
                    iconEnabledColor: Colors.black,
                    items: <String>[
                      'Credit',
                      'Debit',
                    ].map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Container(
                          width: 80.w,
                          child: Text(
                            value,
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                      );
                    }).toList(),
                    hint: Text(
                      "--Select Type--",
                      style: TextStyle(color: Colors.black, fontSize: 10.sp),
                    ),
                    onChanged: (String value) {
                      setState(() {
                        _chosenValue = value;
                      });
                    },
                  ),
                ),
                SizedBox(
                  height: 4.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: name,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter name", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter name',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: mobile,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter mobile", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter mobile',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),   
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: refername,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter refername", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter refername',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),

                // refer mobile 

                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: refermobile,
                  keyboardType: TextInputType.number,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter refermobile", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter refermobile',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),

                // enter amount

                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: amount,
                  keyboardType: TextInputType.number,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter amount", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter amount',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                

                SizedBox(
                  height: 3.h,
                ),
                Container(
                  alignment: Alignment.center,
                  child: InkWell(
                    onTap: () {
                      selectdate(context);
                    },
                    child: Container(
                      padding: EdgeInsets.fromLTRB( 10, 18, 0, 18),
                        alignment: Alignment.topLeft,
                        width: 100.w,
                        decoration: BoxDecoration(
                            border: Border.all(color: yellow, width: 1),
                            borderRadius: BorderRadius.circular(5)),
                        child: Text("${dt.day}-${dt.month}-${dt.year}",
                            textAlign: TextAlign.left,
                            style: TextStyle(fontSize: text))),
                  ),
                ),


                SizedBox(
                  height: 3.h,
                ),
                Container(
                  alignment: Alignment.center,
                  child: InkWell(
                    onTap: () {
                      selectdate(context);
                    },
                    child: Container(
                      padding: EdgeInsets.fromLTRB( 10, 18, 0, 18),
                        alignment: Alignment.topLeft,
                        width: 100.w,
                        decoration: BoxDecoration(
                            border: Border.all(color: yellow, width: 1),
                            borderRadius: BorderRadius.circular(5)),
                        child: Text("${dt.day}-${dt.month}-${dt.year}",
                            textAlign: TextAlign.left,
                            style: TextStyle(fontSize: text))),
                  ),
                ),
                
                // enter caption

                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: caption,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter caption", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter caption',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 5.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                        child: InkWell(
                      onTap: () {},
                      child: expandedbtn("SUBMIT"),
                    )),
                    SizedBox(width: 10),
                    Expanded(
                        child: InkWell(
                      onTap: () {},
                      child: expandedbtn('CANCLE'),
                    )),
                  ],
                )
              ],
            ),
          ),
        ),
        ),
      ),
    );
  }

  selectdate(BuildContext context) async {
    final DateTime pick = await showDatePicker(
      context: context,
      initialDate: dt,
      firstDate: DateTime(1800),
      lastDate: DateTime.now(),
      initialEntryMode: DatePickerEntryMode.calendarOnly,
      // initialDatePickerMode: DatePickerMode.year,
      helpText: 'Select Date',
      cancelText: 'Cancle',
      confirmText: 'Ok',
      errorFormatText: 'Error',
      errorInvalidText: 'Wrong',
      fieldHintText: 'Select date',
      fieldLabelText: 'Enter Date',
    );
    if (pick != null && pick != dt) {
      setState(() {
        dt = pick;
      });
    }
  }
}
