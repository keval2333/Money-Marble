import 'package:budget_finance/globle.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:sizer/sizer.dart';

// display profile

class Profile extends StatefulWidget {
  Profile({Key key}) : super(key: key);

  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                overflow: Overflow.visible,
                children: [
                  Container(
                    height: 25.h,
                    color: yellow,
                  ),
                  Positioned(
                    top: 14.5.h,
                    left: 5.w,
                    child: Row(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.black),
                              borderRadius: BorderRadius.circular(50)),
                          child: CircleAvatar(
                            radius: 6.h,
                            child: Image.asset('assets/images/man.png'),
                          ),
                        ),
                        SizedBox(
                          width: 3.w,
                        ),
                        Container(
                          padding: EdgeInsets.only(bottom: 2.h),
                          child: Text(
                            upname,
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w500,
                                fontSize: heading),
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
              Expanded(
                  child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('assets/images/corner.png'),
                      fit: BoxFit.cover,
                      alignment: Alignment.topCenter),
                ),
                padding: EdgeInsets.fromLTRB(15, 8.h, 15, 15),
                child: Column(
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.push(context, Pageanimated(Updateprofile()));
                      },
                      child: Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Container(child: FaIcon(FontAwesomeIcons.user)),
                                SizedBox(
                                  width: 5.w,
                                ),
                                Container(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text("Name",
                                          style: TextStyle(
                                              fontSize: 10.sp,
                                              color: Colors.black)),
                                      SizedBox(
                                        height: 3,
                                      ),
                                      Text(upname,
                                          style: TextStyle(
                                              fontSize: 9.sp,
                                              color: Colors.grey))
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              child: Icon(
                                Icons.edit,
                                color: Colors.black,
                                size: 20,
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Divider(
                      height: 2,
                      color: Colors.black.withOpacity(0.6),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Container(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                child: Container(
                                    child: FaIcon(FontAwesomeIcons.phoneAlt)),
                              ),
                              SizedBox(
                                width: 5.w,
                              ),
                              Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("Mobile no",
                                        style: TextStyle(
                                            fontSize: 10.sp,
                                            color: Colors.black)),
                                    SizedBox(
                                      height: 3,
                                    ),
                                    Text("9924685972",
                                        style: TextStyle(
                                            fontSize: 9.sp, color: Colors.grey))
                                  ],
                                ),
                              ),
                            ],
                          ),
                          Container(
                            child: Icon(
                              Icons.edit,
                              color: Colors.black,
                              size: 20,
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Divider(
                      height: 2,
                      color: Colors.black.withOpacity(0.6),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Container(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                  child: Image.asset(
                                "assets/icons/email.png",
                                height: 4.h,
                              )),
                              SizedBox(
                                width: 5.w,
                              ),
                              Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("Email Address",
                                        style: TextStyle(
                                            fontSize: 10.sp,
                                            color: Colors.black)),
                                    SizedBox(
                                      height: 3,
                                    ),
                                    Text("bhuvakeval0909@gmail.com",
                                        style: TextStyle(
                                            fontSize: 9.sp, color: Colors.grey))
                                  ],
                                ),
                              ),
                            ],
                          ),
                          Container(
                            child: Icon(
                              Icons.edit,
                              color: Colors.black,
                              size: 20,
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                  ],
                ),
              ))
            ],
          ),
        ),
      ),
    );
  }
}

String upname = "Bhuva keval";
// update profile

class Updateprofile extends StatefulWidget {
  Updateprofile({Key key}) : super(key: key);

  @override
  _UpdateprofileState createState() => _UpdateprofileState();
}

class _UpdateprofileState extends State<Updateprofile> {
  var frmkey1 = GlobalKey<FormState>();
  TextEditingController update = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          height: 100.h,
          width: 100.w,
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          padding: EdgeInsets.fromLTRB(15, 8.h, 15, 15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                child: Text(
                  'Update Your Name',
                  style: TextStyle(
                    fontSize: title,
                  ),
                ),
              ),
              SizedBox(
                height: 5.h,
              ),
              Form(
                key: frmkey1,
                child: TextFormField(
                  cursorColor: yellow,
                  controller: update,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Wrong!!", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter name',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
              ),
              SizedBox(
                height: 5.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                      child: InkWell(
                    onTap: () {
                      upname=update.text;
                         Navigator.push(context,
                                        Pageanimated(Profile()));
                      },
                    child: expandedbtn("UPDTE"),
                  )),
                  SizedBox(width: 10),
                  Expanded(
                      child: InkWell(
                    onTap: () {},
                    child: expandedbtn('CANCLE'),
                  )),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
