import 'package:budget_finance/screen/home_activity.dart';
import 'package:budget_finance/screen/profile_activity.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:titled_navigation_bar/titled_navigation_bar.dart';
import 'package:sizer/sizer.dart';

class Bottombar extends StatefulWidget {
  Bottombar({Key key}) : super(key: key);

  @override
  _BottombarState createState() => _BottombarState();
}

class _BottombarState extends State<Bottombar> {
  int page = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: TitledBottomNavigationBar(
            activeColor: Colors.black,
            currentIndex: page,  
            onTap: (index) {
              setState(() {
                page = index;
              });
            },
            items: [
              TitledNavigationBarItem(title: Text('Home',style: TextStyle(fontSize: 10.sp),), icon: FontAwesomeIcons.home,),
             
              TitledNavigationBarItem(
                  title: Text('Profile',style: TextStyle(fontSize: 10.sp)), icon: FontAwesomeIcons.user),
            ]),
        body: cl[page]);
  }
  List cl = [
    Home(),
    Profile(),
  ];
}