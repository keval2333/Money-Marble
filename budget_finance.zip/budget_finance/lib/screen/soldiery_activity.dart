import 'package:budget_finance/globle.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:folding_cell/folding_cell/widget.dart';
import 'package:sizer/sizer.dart';

// display soldiery

class Displaysoldieryname extends StatefulWidget {
  Displaysoldieryname({Key key}) : super(key: key);

  @override
  _DisplaysoldierynameState createState() => _DisplaysoldierynameState();
}

class _DisplaysoldierynameState extends State<Displaysoldieryname> {
  var _foldingCellKey = GlobalKey<SimpleFoldingCellState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context, Pageanimated(Fetchsoldierymaindata()));
        },
        child: CircleAvatar(
          backgroundColor: yellow,
          radius: 4.1.h,
          child: Icon(
            Icons.add,
            color: Colors.white,
            size: 4.h,
          ),
        ),
      ),
      body: Container(
        child: Column(
            children: [
              SizedBox(height: 30),
              SimpleFoldingCell.create(
                key: _foldingCellKey,
                frontWidget: _buildFrontWidget(),
                innerWidget: _buildInnerWidget(),
                cellSize: Size(100.w, 19.h),
                padding: EdgeInsets.all(12),
                animationDuration: Duration(milliseconds: 900),
                borderRadius: 10,
                onOpen: () => print('cell opened'),
                onClose: () => print('cell closed'),
              ),
            ],
          ),
      ),
    );
  }

  
  Widget _buildFrontWidget() {
    return InkWell(
      onTap: () {
        _foldingCellKey?.currentState?.toggleFold();
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: yellow,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(4.w, 0.5.h, 4.w, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 3.h,
                  ),
                  Container(
                    width: 100.w,
                    alignment: Alignment.topLeft,
                    child: Text(
                      'Lonawala Trip',
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        fontSize: title,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Container(
                        width: 20.w,
                        child: Text(
                          'Person',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '5 people',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Container(
                        width: 20.w,
                        child: Text(
                          'Date',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '12-3-2021',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(bottom: 10, right: 10),
              child: InkWell(
                child: shortbtncardwhite("OPEN"),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInnerWidget() {
    return InkWell(
      onTap: () {
        _foldingCellKey?.currentState?.toggleFold();
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: yellow,width: 2.5),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: 100.w,
                color: yellow,
                padding: EdgeInsets.fromLTRB(4.w, 0.5.h, 4.w, 25),
                child: Column(
                  children: [
                    SizedBox(
                      height: 3.h,
                    ),
                    Container(
                      width: 100.w,
                      alignment: Alignment.topLeft,
                      child: Text(
                        'Lonawala trip',
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          fontSize: title,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Container(
                          width: 20.w,
                          child: Text(
                            'Person',
                            style: TextStyle(
                              fontSize: text,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 2.w,
                        ),
                        Container(
                          child: Text(
                            '5 people',
                            style: TextStyle(
                              fontSize: text,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Row(
                      children: [
                        Container(
                          width: 20.w,
                          child: Text(
                            'Date',
                            style: TextStyle(
                              fontSize: text,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 2.w,
                        ),
                        Container(
                          child: Text(
                            '22-2-2021',
                            style: TextStyle(
                              fontSize: text,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                width: 100.w,
                color: Colors.white,
                padding: EdgeInsets.only(left: 2.w, right: 2.w, top: 2.h),
                child: Column(
                  children: [
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Container(
                          width: 23.w,
                          child: Text(
                            'Installment',
                            style: TextStyle(
                              fontSize: text,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 2.w,
                        ),
                        Container(
                          child: Text(
                            '12500',
                            style: TextStyle(
                              fontSize: text,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Container(
                          width: 23.w,
                          child: Text(
                            'Cus. name',
                            style: TextStyle(
                              fontSize: text,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 2.w,
                        ),
                        Container(
                          child: Text(
                            'krrish sutariya',
                            style: TextStyle(
                              fontSize: text,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Container(
                          width: 23.w,
                          child: Text(
                            'Percentage',
                            style: TextStyle(
                              fontSize: text,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 2.w,
                        ),
                        Container(
                          child: Text(
                            '12%',
                            style: TextStyle(
                              fontSize: text,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Container(
                          width: 23.w,
                          child: Text(
                            'ins. date',
                            style: TextStyle(
                              fontSize: text,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 2.w,
                        ),
                        Container(
                          // color: Colors.red,
                          width: 62.w,
                          child: Text(
                            '12-03-2021',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: text,
                            ),
                          ),
                        ),
                      ],
                    ),
                 
                  ],
                ),
              ),
              Container(
                width: 100.w,
                color: Colors.white,
                child: Container(
                  alignment: Alignment.bottomRight,
                  margin: EdgeInsets.only(bottom: 10, right: 10),
                  child: shortbtncard("CLOSE"),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }


}

// fetch soldiery main data

class Fetchsoldierymaindata extends StatefulWidget {
  Fetchsoldierymaindata({Key key}) : super(key: key);

  @override
  _FetchsoldierymaindataState createState() => _FetchsoldierymaindataState();
}

class _FetchsoldierymaindataState extends State<Fetchsoldierymaindata> {
  TextEditingController soldieryname = new TextEditingController();
  TextEditingController soldieryperson = new TextEditingController();
  DateTime dt = DateTime.now();
  var frmkey1 = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/images/corner.png'),
              fit: BoxFit.cover,
              alignment: Alignment.topCenter),
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.all(10),
          child: Form(
            key: frmkey1,
            child: Column(
              children: [
                SizedBox(
                  height: 8.h,
                ),
                headingtext('Create Soldiery'),
                SizedBox(
                  height: 5.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: soldieryname,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter soldiery name", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter soldiery name',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: soldieryperson,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter number of person", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter no of person',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  alignment: Alignment.center,
                  child: InkWell(
                    onTap: () {
                      selectdate(context);
                    },
                    child: Container(
                        padding: EdgeInsets.fromLTRB(10, 18, 0, 18),
                        alignment: Alignment.topLeft,
                        width: 100.w,
                        decoration: BoxDecoration(
                            border: Border.all(color: yellow, width: 1),
                            borderRadius: BorderRadius.circular(5)),
                        child: Text("${dt.day}-${dt.month}-${dt.year}",
                            textAlign: TextAlign.left,
                            style: TextStyle(fontSize: text))),
                  ),
                ),
                SizedBox(
                  height: 6.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                        child: InkWell(
                      onTap: () {
                        Navigator.push(
                            context, Pageanimated(Fetchsoldiertalldata()));
                      },
                      child: expandedbtn("SUBMIT"),
                    )),
                    SizedBox(width: 10),
                    Expanded(
                        child: InkWell(
                      onTap: () {},
                      child: expandedbtn('CANCLE'),
                    )),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  selectdate(BuildContext context) async {
    final DateTime pick = await showDatePicker(
      context: context,
      initialDate: dt,
      firstDate: DateTime(1800),
      lastDate: DateTime.now(),
      initialEntryMode: DatePickerEntryMode.calendarOnly,
      helpText: 'Select Soldiery Date',
      cancelText: 'Cancle',
      confirmText: 'Ok',
      errorFormatText: 'Error',
      errorInvalidText: 'Wrong',
      fieldHintText: 'Select date',
      fieldLabelText: 'Enter Date',
    );
    if (pick != null && pick != dt) {
      setState(() {
        dt = pick;
      });
    }
  }
}

// fetch soldiery all data

class Fetchsoldiertalldata extends StatefulWidget {
  Fetchsoldiertalldata({Key key}) : super(key: key);

  @override
  _FetchsoldiertalldataState createState() => _FetchsoldiertalldataState();
}

class _FetchsoldiertalldataState extends State<Fetchsoldiertalldata> {
  TextEditingController name = new TextEditingController();
  TextEditingController amount = new TextEditingController();
  TextEditingController reason = new TextEditingController();
  DateTime dt = DateTime.now();
  var frmkey1 = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: EdgeInsets.all(10),
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/images/corner.png'),
              fit: BoxFit.cover,
              alignment: Alignment.topCenter),
        ),
        child: Column(
          children: [
            SizedBox(
              height: 7.h,
            ),
            headingtext('Soldiery transection entry'),
            SizedBox(
              height: 20,
            ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    child: Text('Lonavala Trip',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: title
                    ),),
                  ),
                  Container(
                    child: Text('23/4/2021',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: title
                    ),),
                  )
                ],
              ),
            ),
            
            Expanded(
              child:  SingleChildScrollView(
          padding: EdgeInsets.all(10),
          child: Form(
            key: frmkey1,
            child: Column(
              children: [
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: name,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter person name", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter Person name',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: amount,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter amount", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter amount',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  alignment: Alignment.center,
                  child: InkWell(
                    onTap: () {
                      selectdate(context);
                    },
                    child: Container(
                        padding: EdgeInsets.fromLTRB(10, 18, 0, 18),
                        alignment: Alignment.topLeft,
                        width: 100.w,
                        decoration: BoxDecoration(
                            border: Border.all(color: yellow, width: 1),
                            borderRadius: BorderRadius.circular(5)),
                        child: Text("${dt.day}-${dt.month}-${dt.year}",
                            textAlign: TextAlign.left,
                            style: TextStyle(fontSize: text))),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: amount,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter reason", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter reason',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 6.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                        child: InkWell(
                      onTap: () {
                        Navigator.push(
                            context, Pageanimated(Showsoldierydata()));
                      },
                      child: expandedbtn("SUBMIT"),
                    )),
                    SizedBox(width: 10),
                    Expanded(
                        child: InkWell(
                      onTap: () {},
                      child: expandedbtn('CANCLE'),
                    )),
                  ],
                )
              ],
            ),
          ),
        ), 
            )
          ],
        )
      ),
    );
  }
    selectdate(BuildContext context) async {
    final DateTime pick = await showDatePicker(
      context: context,
      initialDate: dt,
      firstDate: DateTime(1800),
      lastDate: DateTime.now(),
      initialEntryMode: DatePickerEntryMode.calendarOnly,
      helpText: 'Select Soldiery Date',
      cancelText: 'Cancle',
      confirmText: 'Ok',
      errorFormatText: 'Error',
      errorInvalidText: 'Wrong',
      fieldHintText: 'Select date',
      fieldLabelText: 'Enter Date',
    );
    if (pick != null && pick != dt) {
      setState(() {
        dt = pick;
      });
    }
  }
}



// show soldiery data

class Showsoldierydata extends StatefulWidget {
  Showsoldierydata({Key key}) : super(key: key);

  @override
  _ShowsoldierydataState createState() => _ShowsoldierydataState();
}

class _ShowsoldierydataState extends State<Showsoldierydata> {
  @override
  Widget build(BuildContext context) {
    return Container(
       child: null,
    );
  }
}
