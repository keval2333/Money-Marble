import 'package:budget_finance/globle.dart';
import 'package:budget_finance/screen/home_activity.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:folding_cell/folding_cell/widget.dart';
import 'package:share/share.dart';
import 'package:sizer/sizer.dart';

// bank detail  display data

class Bankdetaildisplay extends StatefulWidget {
  Bankdetaildisplay({Key key}) : super(key: key);

  @override
  _BankdetaildisplayState createState() => _BankdetaildisplayState();
}

class _BankdetaildisplayState extends State<Bankdetaildisplay> {
  var _foldingCellKey = GlobalKey<SimpleFoldingCellState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.push(context, Pageanimated(Bankdetailfetch()));
          },
          child: CircleAvatar(
            backgroundColor: yellow,
            radius: 4.1.h,
            child: Icon(
              Icons.add,
              color: Colors.white,
              size: 4.h,
            ),
          ),
        ),
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          child: Column(
            children: [
              SizedBox(height: 30),
              SimpleFoldingCell.create(
                key: _foldingCellKey,
                frontWidget: _buildFrontWidget(),
                innerWidget: _buildInnerWidget(),
                cellSize: Size(100.w, 23.h),
                padding: EdgeInsets.all(15),
                animationDuration: Duration(milliseconds: 900),
                borderRadius: 10,
                onOpen: () => print('cell opened'),
                onClose: () => print('cell closed'),
              ),
            ],
          ),
        ));
  }
    Widget _buildFrontWidget() {
    return InkWell(
      onTap: () {
        _foldingCellKey?.currentState?.toggleFold();
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: yellow,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(2.w, 0.5.h, 2.w, 0),
              child: Column(
                children: [
                  SizedBox(
                    height: 3.h,
                  ),
                  Text(
                    'SBI Bank',
                    style: TextStyle(
                      fontSize: heading,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(
                    height: 2.h,
                  ),
                  Text(
                    'BHUVA KEVAL MUKESHBHAI',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: text,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(bottom:10,right:10),
              child: InkWell(
                child: shortbtncardwhite("OPEN"),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInnerWidget() {
    return InkWell(
      onTap: () {
        _foldingCellKey?.currentState?.toggleFold();
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: yellow), 
        ),
        
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              width: 100.w,
              color: yellow,
              padding: EdgeInsets.fromLTRB(2.w, 0.5.h, 2.w, 30),
              child: Column(
                children: [
                  SizedBox(
                    height: 3.h,
                  ),
                  Text(
                    'SBI Bank',
                    style: TextStyle(
                      fontSize: heading,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(
                    height: 2.h,
                  ),
                  Text(
                    'BHUVA KEVAL MUKESHBHAI',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: text,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 100.w,
              color: Colors.white,
              padding: EdgeInsets.only(left: 2.w, right: 2.w,top: 2.h),
              child: Column(
                children: [
                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Container(
                        width: 23.w,
                        child: Text(
                          'A/C no',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '1234098736543',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Container(
                        width: 23.w,
                        child: Text(
                          'Mobile no',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '9924685972',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Container(
                        width: 23.w,
                        child: Text(
                          'Email',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          'bhuvakeva0909@gmail.com',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Container(
                        width: 23.w,
                        child: Text(
                          'IFSC code',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        // color: Colors.red,
                        width: 62.w,
                        child: Text(
                          '8256312045125678',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Container(
                        width: 23.w,
                        child: Text(
                          'SWIFT code',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '12345678807652',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              width: 100.w,
              color: Colors.white,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    alignment: Alignment.bottomRight,
                    margin: EdgeInsets.only(bottom:10,right:10),
                    child: shortbtncard("CLOSE"),
                  ),
                  Container(
                    alignment: Alignment.bottomRight,
                    margin: EdgeInsets.only(bottom:10,right:10),
                    child: InkWell(
                      onTap: (){
                        Share.share("\t\t\tSBI Bank\n\nName: Bhuva keval mukeshbhai\nA/C no : 1234567890345\nMobile no : 9924685972\nEmail : bhuvakeval0909@gmail.com\nIFSC code : 12345678900987\nSWIFT code : 1234566799765 "
                        );
                      },
                      child: shortbtncard("SHARE"),
                    )
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

}


// bank detal fetch

class Bankdetailfetch extends StatefulWidget {
  Bankdetailfetch({Key key}) : super(key: key);

  @override
  _BankdetailfetchState createState() => _BankdetailfetchState();
}

class _BankdetailfetchState extends State<Bankdetailfetch> {
  var frmkey1 = GlobalKey<FormState>();
  TextEditingController bankname = new TextEditingController();
  TextEditingController accountnumber = new TextEditingController();
  TextEditingController personname = new TextEditingController();
  TextEditingController linkmobile = new TextEditingController();
  TextEditingController linkemail = new TextEditingController();
  TextEditingController ifsccode = new TextEditingController();
  TextEditingController swiftcode = new TextEditingController();
  FocusNode f1 = FocusNode();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/images/corner.png'),
              fit: BoxFit.cover,
              alignment: Alignment.topCenter),
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.all(15),
          child: Form(
            key: frmkey1,
            child: Column(
              children: [
                SizedBox(
                  height: 6.h,
                ),
                headingtext('Bank Detail'),

                // bank namw
                SizedBox(
                  height: 4.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: bankname,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter bankname", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter bankname',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),

                // account number
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: accountnumber,
                  keyboardType: TextInputType.number,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter accountnumber", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter accountnumber',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),

                //person name

                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: personname,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter personname", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter personname',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),

                //Linkmobile

                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: linkmobile,
                  keyboardType: TextInputType.number,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter mobile", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter mobile',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),

                //link email

                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: linkemail,
                  keyboardType: TextInputType.emailAddress,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter email", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter email',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),

                // ifsc code

                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: ifsccode,
                  keyboardType: TextInputType.number,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter IFSC code", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter IFSC code',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),

                // swift code

                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: swiftcode,
                  keyboardType: TextInputType.number,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter swiftcode", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter swiftcode',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                
                SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                        child: InkWell(
                      onTap: () {
                        if (getdata1() == true) {
                          print("kk yes");
                          
                        }
                        else{
                          print("kk no");
                          Navigator.push(context, Pageanimated(Home()));
                        }
                      },
                      child: expandedbtn("SUBMIT"),
                    )),
                    SizedBox(width: 10),
                    Expanded(
                        child: InkWell(
                      onTap: () {},
                      child: expandedbtn('CANCLE'),
                    )),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  getdata1() {
    final checkfrm2 = frmkey1.currentState.validate();
    if (!checkfrm2) {
      return true;
    }
    frmkey1.currentState.save();
    return false;
  }
}
