import 'dart:ui';
import 'package:budget_finance/globle.dart';
import 'package:budget_finance/screen/splash_activity.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animator/animation/animation_preferences.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter_animator/flutter_animator.dart';

class Onboarding extends StatefulWidget {
  Onboarding({Key key}) : super(key: key);

  @override
  _OnboardingState createState() => _OnboardingState();
}

class _OnboardingState extends State<Onboarding> {
  PageController controller = new PageController(
    initialPage: 0,
  );
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          child: PageView(
        controller: controller,
        children: [
          Container(
            height: 100.h,
            width: 100.w,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/images/onboarding1.jpg'),
                    fit: BoxFit.cover)),
            child: Stack(
              children: [
                Container(
                  padding: EdgeInsets.only(top:19.h),
                  child: Image.asset('assets/images/onimage1.png',
                  height: 50.h),
                ),
                Column(
                  children: [
                    SizedBox(
                      height: 5.h,
                    ),
                    InkWell(
                      onTap: (){
                         controller.nextPage(duration: Duration(milliseconds: 1000), curve: Curves.ease);
                      },
                      child: Container(
                        padding: EdgeInsets.only(right:15),
                        alignment: Alignment.topRight,
                        child: CircleAvatar(
                          radius: 3.h,
                          backgroundColor: yellow,
                          child: Icon(Icons.arrow_forward,color: Colors.white,),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 72.h,
                    ),
                    FadeInUpBig(
                      preferences: AnimationPreferences(autoPlay: AnimationPlayStates.Forward,duration: Duration(milliseconds: 1350),),
                      child: Container(
                          alignment: Alignment.center,
                          child: Text(
                            "MANAGE INCOME EXPENSE",
                            style: TextStyle(
                              fontSize: title,
                              letterSpacing: 0.5,
                              fontWeight: FontWeight.bold,
                            ),
                          )),
                    ),
                    SizedBox(
                      height: 1.5.h,
                    ),
                    FadeInRight(
                      preferences: AnimationPreferences(autoPlay: AnimationPlayStates.Forward,duration: Duration(milliseconds: 1000),),
                      child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 3.h),
                          alignment: Alignment.center,
                          child: Text(
                            "Use this app today to properly manage the expenses and income in our daily life",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: text,
                              height: 1.2,
                            ),
                          )),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            height: 100.h,
            width: 100.w,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/images/onboarding2.jpg'),
                    fit: BoxFit.cover)),
            child: Stack(
              children: [
                Container(
                  margin: EdgeInsets.only(left:13.w),
                  padding: EdgeInsets.only(top:30.h),
                  child: Image.asset('assets/images/onimage2.png',height: 38.h),
                ),
                Column(
                  children: [
                    SizedBox(
                      height: 5.h,
                    ),
                    Container(
                      padding: EdgeInsets.only(right:15,left:15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(),
                          InkWell(
                            onTap: (){
                               controller.nextPage(duration: Duration(milliseconds: 1000), curve: Curves.ease);
                            },
                            child: Container(
                              alignment: Alignment.topRight,
                              child: CircleAvatar(
                                radius: 3.h,
                                backgroundColor: yellow,
                                child: Icon(Icons.arrow_forward,color: Colors.white,),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 72.h,
                    ),
                    FadeInUpBig(
                      preferences: AnimationPreferences(autoPlay: AnimationPlayStates.Forward,duration: Duration(milliseconds: 1350),),
                      child: Container(
                          alignment: Alignment.center,
                          child: Text(
                            "MANAGE INVESTMENT",
                            style: TextStyle(
                              fontSize: title,
                              letterSpacing: 0.5,
                              fontWeight: FontWeight.bold,
                            ),
                          )),
                    ),
                    SizedBox(
                      height: 1.5.h,
                    ),
                    FadeInRight(
                      preferences: AnimationPreferences(autoPlay: AnimationPlayStates.Forward,duration: Duration(milliseconds: 1000),),
                      child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 3.h),
                          alignment: Alignment.center,
                          child: Text(
                            "Use it today to easily handle your investment and know its current status",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: text,
                              height: 1.2,
                            ),
                          )),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            height: 100.h,
            width: 100.w,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/images/onboarding3.jpg'),
                    fit: BoxFit.cover)),
            child: Stack(
              children: [
                Container(
                  margin: EdgeInsets.only(left:22),
                  padding: EdgeInsets.only(top:22.h),
                  child: Image.asset('assets/images/onimage3.png',height: 42.h),
                ),
                Column(
                  children: [
                    SizedBox(
                      height: 5.h,
                    ),
                    Container(
                  padding: EdgeInsets.only(left: 10,right:10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(),
                InkWell(
                  onTap: (){
                    Navigator.push(context, Pageanimated(SecondClass()));    
                  },
                  child: Container(
                    padding: EdgeInsets.fromLTRB(10, 7, 10, 7),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: yellow,
                    ),
                    child: Text('Get Start',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: text
                    ),)
                  ),
                ),
                    ],
                  ),
                ),
                    SizedBox(
                      height: 74.5.h,
                    ),
                    FadeInUpBig(
                      preferences: AnimationPreferences(autoPlay: AnimationPlayStates.Forward,duration: Duration(milliseconds: 1350),),
                      child: Container(
                          alignment: Alignment.center,
                          child: Text(
                            "CALCULATION",
                            style: TextStyle(
                              fontSize: title,
                              letterSpacing: 0.5,
                              fontWeight: FontWeight.bold,
                            ),
                          )),
                    ),
                    SizedBox(
                      height: 1.5.h,
                    ),
                    FadeInRight(
                      preferences: AnimationPreferences(autoPlay: AnimationPlayStates.Forward,duration: Duration(milliseconds: 1000),),
                      child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 3.h),
                          alignment: Alignment.center,
                          child: Text(
                            "Loan Calculator, Investment Calculator, Age Calculator, Currency Calculator",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: text,
                              height: 1.2,
                            ),
                          )),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      )),
    );
  }
}
