import 'dart:io';
import 'package:budget_finance/globle.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:folding_cell/folding_cell/widget.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';

// display bill data

class Billdisplay extends StatefulWidget {
  Billdisplay({Key key}) : super(key: key);

  
  _BilldisplayState createState() => _BilldisplayState();
}

class _BilldisplayState extends State<Billdisplay> {
  var _foldingCellKey = GlobalKey<SimpleFoldingCellState>();
  @override
  void initState() { 
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.push(context, Pageanimated(Billdatafetch()));
          },
          child: CircleAvatar(
            backgroundColor: yellow,
            radius: 4.1.h,
            child: Icon(
              Icons.add,
              color: Colors.white,
              size: 4.h,
            ),
          ),
        ),
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          child: Column(
            children: [
              SizedBox(height: 30),
              SimpleFoldingCell.create(
                key: _foldingCellKey,
                frontWidget: _buildFrontWidget(),
                innerWidget: _buildInnerWidget(),
                cellSize: Size(100.w, 23.h),
                padding: EdgeInsets.all(15),
                animationDuration: Duration(milliseconds: 900),
                borderRadius: 10,
                onOpen: () => print('cell opened'),
                onClose: () => print('cell closed'),
              ),
            ],
          ),
        ));
  }

  Widget _buildFrontWidget() {
    return InkWell(
      onTap: () {
        _foldingCellKey?.currentState?.toggleFold();
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: yellow,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(2.w, 0.5.h, 2.w, 0),
              child: Column(
                children: [
                  SizedBox(
                    height: 3.h,
                  ),
                  Row(
                    children: [
                      Container(
                        width: 23.w,
                        child: Text(
                          ' Bill Type',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          'Light bill',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 5),
                  Row(
                    children: [
                      Container(
                        width: 23.w,
                        child: Text(
                          'Amount',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '37650',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 5),
                  Row(
                    children: [
                      Container(
                        width: 23.w,
                        child: Text(
                          'Date',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '12-2-2002',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 5),
                  Row(
                    children: [
                      Container(
                        width: 23.w,
                        child: Text(
                          'Gua./warr.',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '2 year',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(bottom: 10, right: 10),
              child: InkWell(
                child: shortbtncardwhite("OPEN"),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInnerWidget() {
    return InkWell(
      onTap: () {
        _foldingCellKey?.currentState?.toggleFold();
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            SizedBox(
              height: 10,
            ),
            Expanded(
              child: Image.asset(
                'assets/images/bill.jpg',
                fit: BoxFit.fill,
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              width: 100.w,
              color: Colors.white,
              child: Container(
                alignment: Alignment.bottomRight,
                margin: EdgeInsets.only(bottom: 10, right: 10),
                child: shortbtncard("CLOSE"),
              ),
            )
          ],
        ),
      ),
    );
  }

}

// bill data fetch

class Billdatafetch extends StatefulWidget {
  Billdatafetch({Key key}) : super(key: key);

  @override
  _BilldatafetchState createState() => _BilldatafetchState();
}

class _BilldatafetchState extends State<Billdatafetch> {
  File imagepath;
  var frmkey1 = GlobalKey<FormState>();
  DateTime dt = DateTime.now();
  String _chosenValue;
  TextEditingController amount = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/images/corner.png'),
              fit: BoxFit.cover,
              alignment: Alignment.topCenter),
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.all(10),
          child: Form(
            key: frmkey1,
            child: Column(
              children: [
                SizedBox(
                  height: 6.h,
                ),
                headingtext('Manage Bills'),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  padding:
                      EdgeInsets.only(left: 5, top: 13, bottom: 13, right: 5),
                  decoration: BoxDecoration(
                      border: Border.all(color: yellow),
                      borderRadius: BorderRadius.circular(5)),
                  child: DropdownButtonFormField<String>(
                    isExpanded: true,
                    focusColor: Colors.white,
                    decoration: InputDecoration.collapsed(hintText: ''),
                    value: _chosenValue,
                    //elevation: 5,
                    style: TextStyle(color: Colors.white),
                    iconEnabledColor: Colors.black,
                    items: <String>[
                      'Lightbill',
                      'Milkbill',
                      'Productbill',
                      'Gasbill',
                      'Rechargebill',
                      'Other'
                    ].map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Container(
                          width: 80.w,
                          child: Text(
                            value,
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                      );
                    }).toList(),
                    hint: Text(
                      "--Select Type--",
                      style: TextStyle(color: Colors.black, fontSize: 10.sp),
                    ),
                    onChanged: (String value) {
                      setState(() {
                        _chosenValue = value;
                      });
                    },
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: InkWell(
                        onTap: () {
                          print('krrish');
                          fromcam();
                        },
                        child: Container(
                            padding: EdgeInsets.fromLTRB(10, 16, 10, 16),
                            alignment: Alignment.topLeft,
                            decoration: BoxDecoration(
                                border: Border.all(color: yellow, width: 1),
                                borderRadius: BorderRadius.circular(5)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Take photo",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(fontSize: text)),
                                FaIcon(
                                  FontAwesomeIcons.camera,
                                  color: Colors.black,
                                  size: 3.h,
                                )
                              ],
                            )),
                      ),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Expanded(
                      child: Container(
                          alignment: Alignment.center,
                          padding: EdgeInsets.all(2),
                          decoration: BoxDecoration(
                              color: Colors.transparent,
                              border: Border.all(color: yellow, width: 1),
                              borderRadius: BorderRadius.circular(5)),
                          height: 8.h,
                          child: imagepath == null
                              ? Text(
                                  'Bill\nPhoto',
                                  textAlign: TextAlign.center,
                                )
                              : Image.file(
                                  imagepath,
                                  fit: BoxFit.cover,
                                )),
                    ),
                  ],
                ),
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: amount,
                  keyboardType: TextInputType.number,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter amount", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter amount',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  alignment: Alignment.center,
                  child: InkWell(
                    onTap: () {
                      selectdate(context);
                    },
                    child: Container(
                        padding: EdgeInsets.fromLTRB(10, 18, 0, 18),
                        alignment: Alignment.topLeft,
                        width: 100.w,
                        decoration: BoxDecoration(
                            border: Border.all(color: yellow, width: 1),
                            borderRadius: BorderRadius.circular(5)),
                        child: Text("${dt.day}-${dt.month}-${dt.year}",
                            textAlign: TextAlign.left,
                            style: TextStyle(fontSize: text))),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  alignment: Alignment.topLeft,
                  child: Text(
                    'Guarrenty or Warranty',
                    textAlign: TextAlign.left,
                    style: TextStyle(fontSize: text),
                  ),
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.only(
                            left: 5, top: 13, bottom: 13, right: 5),
                        decoration: BoxDecoration(
                            border: Border.all(color: yellow),
                            borderRadius: BorderRadius.circular(5)),
                        child: DropdownButtonFormField<String>(
                          isExpanded: true,
                          focusColor: Colors.white,
                          decoration: InputDecoration.collapsed(hintText: ''),
                          value: _chosenValue,
                          //elevation: 5,
                          style: TextStyle(color: Colors.white),
                          iconEnabledColor: Colors.black,
                          items: <String>[
                            '1',
                            '2',
                            '3',
                            '4',
                            '5',
                            '6',
                            '7',
                            '8',
                            '9',
                            '10',
                            '11',
                            '12',
                            '13',
                            '14',
                            '15',
                            '16',
                            '17',
                            '18',
                            '19',
                            '20',
                            '21',
                            '22',
                            '23',
                            '24',
                            '25',
                            '26',
                            '27',
                            '28',
                            '29',
                            '30',
                            '31',
                            '32',
                            '33',
                            '34',
                            '35',
                            '36',
                            '37',
                            '38',
                            '39',
                            '40',
                            '41',
                            '42',
                            '43',
                            '44',
                            '45',
                            '46',
                            '47',
                            '48',
                            '49',
                            '50',
                            '51',
                            '52',
                            '53',
                            '54',
                            '55',
                            '56',
                            '57',
                            '58',
                            '59',
                            '60',
                            '61',
                            '62',
                            '63',
                            '64',
                            '65',
                            '66',
                            '67',
                            '68',
                            '69',
                            '70',
                            '71',
                            '72',
                            '73',
                            '74',
                            '75',
                            '76',
                            '77',
                            '78',
                            '79',
                            '80',
                            '81',
                            '82',
                            '83',
                            '84',
                            '85',
                            '86',
                            '87',
                            '88',
                            '89',
                            '90',
                            '91',
                            '92',
                            '93',
                            '94',
                            '95',
                            '96',
                            '97',
                            '98',
                            '99',
                            '100',
                          ].map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Container(
                                width: 80.w,
                                child: Text(
                                  value,
                                  style: TextStyle(color: Colors.black),
                                ),
                              ),
                            );
                          }).toList(),
                          hint: Text(
                            "--Select Unit--",
                            style:
                                TextStyle(color: Colors.black, fontSize: 10.sp),
                          ),
                          onChanged: (String value) {
                            setState(() {
                              _chosenValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.only(
                            left: 5, top: 13, bottom: 13, right: 5),
                        decoration: BoxDecoration(
                            border: Border.all(color: yellow),
                            borderRadius: BorderRadius.circular(5)),
                        child: DropdownButtonFormField<String>(
                          isExpanded: true,
                          focusColor: Colors.white,
                          decoration: InputDecoration.collapsed(hintText: ''),
                          value: _chosenValue,
                          //elevation: 5,
                          style: TextStyle(color: Colors.white),
                          iconEnabledColor: Colors.black,
                          items: <String>['Day', 'Month', 'Year']
                              .map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Container(
                                width: 80.w,
                                child: Text(
                                  value,
                                  style: TextStyle(color: Colors.black),
                                ),
                              ),
                            );
                          }).toList(),
                          hint: Text(
                            "--Select Duration--",
                            style:
                                TextStyle(color: Colors.black, fontSize: 10.sp),
                          ),
                          onChanged: (String value) {
                            setState(() {
                              _chosenValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                        child: InkWell(
                      onTap: () {},
                      child: expandedbtn("SUBMIT"),
                    )),
                    SizedBox(width: 10),
                    Expanded(
                        child: InkWell(
                      onTap: () {},
                      child: expandedbtn('CANCLE'),
                    )),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  void fromcam() async {
    // take images path for cemera
    PickedFile pfile = await ImagePicker().getImage(
      source: ImageSource.camera,
      maxWidth: 720,
      maxHeight: 1280,
    );

    // set path for another variable
    if (pfile != null) {
      setState(() {
        imagepath = File(pfile.path);
      });
    }
  }

  selectdate(BuildContext context) async {
    final DateTime pick = await showDatePicker(
      context: context,
      initialDate: dt,
      firstDate: DateTime(1800),
      lastDate: DateTime.now(),
      initialEntryMode: DatePickerEntryMode.calendarOnly,
      // initialDatePickerMode: DatePickerMode.year,
      helpText: 'Select Installment Date',
      cancelText: 'Cancle',
      confirmText: 'Ok',
      errorFormatText: 'Error',
      errorInvalidText: 'Wrong',
      fieldHintText: 'Select Installmentdate',
      fieldLabelText: 'Enter Installmentdate',
    );
    if (pick != null && pick != dt) {
      setState(() {
        dt = pick;
      });
    }
  }
}
