import 'package:budget_finance/globle.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:folding_cell/folding_cell/widget.dart';
import 'package:share/share.dart';
import 'package:sizer/sizer.dart';

// loan detail display

class Loandetaildisplay extends StatefulWidget {
  Loandetaildisplay({Key key}) : super(key: key);

  @override
  _LoandetaildisplayState createState() => _LoandetaildisplayState();
}

class _LoandetaildisplayState extends State<Loandetaildisplay> {
  var _foldingCellKey = GlobalKey<SimpleFoldingCellState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.push(context, Pageanimated(Loandetailfetch()));
          },
          child: CircleAvatar(
            backgroundColor: yellow,
            radius: 4.1.h,
            child: Icon(
              Icons.add,
              color: Colors.white,
              size: 4.h,
            ),
          ),
        ),
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          child: Column(
            children: [
              SizedBox(height: 30),
              SimpleFoldingCell.create(
                key: _foldingCellKey,
                frontWidget: _buildFrontWidget(),
                innerWidget: _buildInnerWidget(),
                cellSize: Size(100.w, 23.h),
                padding: EdgeInsets.all(15),
                animationDuration: Duration(milliseconds: 900),
                borderRadius: 10,
                onOpen: () => print('cell opened'),
                onClose: () => print('cell closed'),
              ),
            ],
          ),
        ));
  }

  Widget _buildFrontWidget() {
    return InkWell(
      onTap: () {
        _foldingCellKey?.currentState?.toggleFold();
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: yellow,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(4.w, 0.5.h, 4.w, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 3.h,
                  ),
                  Container(
                    width: 100.w,
                    alignment: Alignment.topLeft,
                    child: Text(
                      'Bajaj Finance Loan',
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        fontSize: title,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Container(
                        width: 20.w,
                        child: Text(
                          'Amount',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '12500',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Container(
                        width: 20.w,
                        child: Text(
                          'Duration',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '2 year',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(bottom: 10, right: 10),
              child: InkWell(
                child: shortbtncardwhite("OPEN"),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInnerWidget() {
    return InkWell(
      onTap: () {
        _foldingCellKey?.currentState?.toggleFold();
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: yellow),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              width: 100.w,
              color: yellow,
              padding: EdgeInsets.fromLTRB(4.w, 0.5.h, 4.w, 30),
              child: Column(
                children: [
                  SizedBox(
                    height: 3.h,
                  ),
                  Container(
                    width: 100.w,
                    alignment: Alignment.topLeft,
                    child: Text(
                      'Bajaj Finance Loan',
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        fontSize: title,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Container(
                        width: 20.w,
                        child: Text(
                          'Amount',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '12500',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Container(
                        width: 20.w,
                        child: Text(
                          'Duration',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '2 year',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              width: 100.w,
              color: Colors.white,
              padding: EdgeInsets.only(left: 2.w, right: 2.w, top: 2.h),
              child: Column(
                children: [
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Container(
                        width: 23.w,
                        child: Text(
                          'Installment',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '12500',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Container(
                        width: 23.w,
                        child: Text(
                          'Cus. name',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          'bhuva keval',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Container(
                        width: 23.w,
                        child: Text(
                          'Percentage',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        child: Text(
                          '12%',
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Container(
                        width: 23.w,
                        child: Text(
                          'ins. date',
                          style: TextStyle(
                            fontSize: text,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Container(
                        // color: Colors.red,
                        width: 62.w,
                        child: Text(
                          '12-03-2021',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: text,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              width: 100.w,
              color: Colors.white,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    alignment: Alignment.bottomRight,
                    margin: EdgeInsets.only(bottom: 10, right: 10),
                    child: shortbtncard("CLOSE"),
                  ),
                  Container(
                      alignment: Alignment.bottomRight,
                      margin: EdgeInsets.only(bottom: 10, right: 10),
                      child: InkWell(
                        onTap: () {
                          Share.share(
                              "\t\t\tHDFC Bank\n\nName: Sutariya krrish maheshbhai\nA/C no : 1234567890345\nMobile no : 1234567890\nEmail : abcd1234@gmail.com\nIFSC code : 12345678900987\nSWIFT code : 1234566799765 ");
                        },
                        child: shortbtncard("SHARE"),
                      )),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

// loan detail fetch

class Loandetailfetch extends StatefulWidget {
  Loandetailfetch({Key key}) : super(key: key);

  @override
  _LoandetailfetchState createState() => _LoandetailfetchState();
}

class _LoandetailfetchState extends State<Loandetailfetch> {
  var frmkey1 = GlobalKey<FormState>();
  String _chosenValue;
  TextEditingController loanname = new TextEditingController();
  TextEditingController loanamount = new TextEditingController();
  DateTime dt = DateTime.now();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/images/corner.png'),
              fit: BoxFit.cover,
              alignment: Alignment.topCenter),
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.all(10),
          child: Form(
            key: frmkey1,
            child: Column(
              children: [
                SizedBox(
                  height: 6.h,
                ),
                headingtext('Loan detail'),
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: loanname,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter loanname", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter loanname',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: loanamount,
                  keyboardType: TextInputType.number,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter amount", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter amount',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.only(
                            left: 5, top: 13, bottom: 13, right: 5),
                        decoration: BoxDecoration(
                            border: Border.all(color: yellow),
                            borderRadius: BorderRadius.circular(5)),
                        child: DropdownButtonFormField<String>(
                          isExpanded: true,
                          focusColor: Colors.white,
                          decoration: InputDecoration.collapsed(hintText: ''),
                          value: _chosenValue,
                          //elevation: 5,
                          style: TextStyle(color: Colors.white),
                          iconEnabledColor: Colors.black,
                          items: <String>[
                            '1',
                            '2',
                            '3',
                            '4',
                            '5',
                            '6',
                            '7',
                            '8',
                            '9',
                            '10',
                            '11',
                            '12',
                            '13',
                            '14',
                            '15',
                            '16',
                            '17',
                            '18',
                            '19',
                            '20',
                            '21',
                            '22',
                            '23',
                            '24',
                            '25',
                            '26',
                            '27',
                            '28',
                            '29',
                            '30',
                            '31',
                            '32',
                            '33',
                            '34',
                            '35',
                            '36',
                            '37',
                            '38',
                            '39',
                            '40',
                            '41',
                            '42',
                            '43',
                            '44',
                            '45',
                            '46',
                            '47',
                            '48',
                            '49',
                            '50',
                            '51',
                            '52',
                            '53',
                            '54',
                            '55',
                            '56',
                            '57',
                            '58',
                            '59',
                            '60',
                            '61',
                            '62',
                            '63',
                            '64',
                            '65',
                            '66',
                            '67',
                            '68',
                            '69',
                            '70',
                            '71',
                            '72',
                            '73',
                            '74',
                            '75',
                            '76',
                            '77',
                            '78',
                            '79',
                            '80',
                            '81',
                            '82',
                            '83',
                            '84',
                            '85',
                            '86',
                            '87',
                            '88',
                            '89',
                            '90',
                            '91',
                            '92',
                            '93',
                            '94',
                            '95',
                            '96',
                            '97',
                            '98',
                            '99',
                            '100',
                          ].map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Container(
                                width: 80.w,
                                child: Text(
                                  value,
                                  style: TextStyle(color: Colors.black),
                                ),
                              ),
                            );
                          }).toList(),
                          hint: Text(
                            "--Select Duration--",
                            style:
                                TextStyle(color: Colors.black, fontSize: 10.sp),
                          ),
                          onChanged: (String value) {
                            setState(() {
                              _chosenValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.only(
                            left: 5, top: 13, bottom: 13, right: 5),
                        decoration: BoxDecoration(
                            border: Border.all(color: yellow),
                            borderRadius: BorderRadius.circular(5)),
                        child: DropdownButtonFormField<String>(
                          isExpanded: true,
                          focusColor: Colors.white,
                          decoration: InputDecoration.collapsed(hintText: ''),
                          value: _chosenValue,
                          //elevation: 5,
                          style: TextStyle(color: Colors.white),
                          iconEnabledColor: Colors.black,
                          items: <String>['Day', 'Month', 'Year']
                              .map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Container(
                                width: 80.w,
                                child: Text(
                                  value,
                                  style: TextStyle(color: Colors.black),
                                ),
                              ),
                            );
                          }).toList(),
                          hint: Text(
                            "--Select Time--",
                            style:
                                TextStyle(color: Colors.black, fontSize: 10.sp),
                          ),
                          onChanged: (String value) {
                            setState(() {
                              _chosenValue = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: loanamount,
                  keyboardType: TextInputType.number,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter installment", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter installment',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: loanamount,
                  keyboardType: TextInputType.number,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter customername", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter customername',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: loanamount,
                  keyboardType: TextInputType.number,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter loanpercentage", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter loanpercentage',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  alignment: Alignment.center,
                  child: InkWell(
                    onTap: () {
                      selectdate(context);
                    },
                    child: Container(
                        padding: EdgeInsets.fromLTRB(10, 18, 0, 18),
                        alignment: Alignment.topLeft,
                        width: 100.w,
                        decoration: BoxDecoration(
                            border: Border.all(color: yellow, width: 1),
                            borderRadius: BorderRadius.circular(5)),
                        child: Text("${dt.day}-${dt.month}-${dt.year}",
                            textAlign: TextAlign.left,
                            style: TextStyle(fontSize: text))),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                        child: InkWell(
                      onTap: () {},
                      child: expandedbtn("SUBMIT"),
                    )),
                    SizedBox(width: 10),
                    Expanded(
                        child: InkWell(
                      onTap: () {},
                      child: expandedbtn('CANCLE'),
                    )),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  selectdate(BuildContext context) async {
    final DateTime pick = await showDatePicker(
      context: context,
      initialDate: dt,
      firstDate: DateTime(1800),
      lastDate: DateTime.now(),
      initialEntryMode: DatePickerEntryMode.calendarOnly,
      // initialDatePickerMode: DatePickerMode.year,
      helpText: 'Select Installment Date',
      cancelText: 'Cancle',
      confirmText: 'Ok',
      errorFormatText: 'Error',
      errorInvalidText: 'Wrong',
      fieldHintText: 'Select Installmentdate',
      fieldLabelText: 'Enter Installmentdate',
    );
    if (pick != null && pick != dt) {
      setState(() {
        dt = pick;
      });
    }
  }
}
