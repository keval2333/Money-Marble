import 'dart:async';
import 'dart:ui';
import 'package:budget_finance/globle.dart';
import 'package:budget_finance/screen/bottombar_activity.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animator/flutter_animator.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:sizer/sizer.dart';
import 'package:titled_navigation_bar/titled_navigation_bar.dart';

class Loginscreen extends StatefulWidget {
  const Loginscreen({Key key}) : super(key: key);

  @override
  _LoginscreenState createState() => _LoginscreenState();
}

class _LoginscreenState extends State<Loginscreen> {
  var frmkey1 = GlobalKey<FormState>();
  TextEditingController mobile = new TextEditingController();
  FocusNode f1 = FocusNode();
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        f1.unfocus();
      },
      child: Scaffold(
        body: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(25),
            height: 100.h,
            width: 100.h,
            decoration: BoxDecoration(
                color: Colors.black,
                image: DecorationImage(
                    image: AssetImage(
                      'assets/images/bg.jpg',
                    ),
                    colorFilter: new ColorFilter.mode(
                        Colors.black.withOpacity(0.3), BlendMode.dstATop),
                    fit: BoxFit.fill)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Bounce(
                  preferences: AnimationPreferences(
                    autoPlay: AnimationPlayStates.Forward,
                    duration: Duration(milliseconds: 2000),
                  ),
                  child: Container(
                    child: Image.asset('assets/icons/png.png', height: 15.h),
                  ),
                ),
                SizedBox(
                  height: 1.h,
                ),
                Container(
                  child: Text(
                    'Sign In',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20.sp,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(
                  height: 5.h,
                ),
                RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    text: 'We will send you an ',
                    style: TextStyle(fontSize: 11, fontFamily: 'VarelaRound'),
                    children: <TextSpan>[
                      TextSpan(
                          text: 'One Time Password',
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontFamily: 'VarelaRound',
                              fontSize: 12)),
                      TextSpan(
                          text: '\nOn this mobile number',
                          style:
                              TextStyle(fontFamily: 'VarelaRound', fontSize: 11)),
                    ],
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Form(
                    key: frmkey1,
                    child: TextFormField(
                      focusNode: f1,
                      cursorColor: yellow,
                      maxLength: 10,
                      controller: mobile,
                      keyboardType: TextInputType.phone,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: text,
                      ),
                      // ignore: missing_return
                      validator: (value) {
                        if (value.isEmpty ||
                            !RegExp(r"^[0-9]{10}$").hasMatch(value)) {
                          return snackBar("Invalid Number", context);
                        } else {
                          Navigator.push(
                              context, Pageanimated(Otpverify(mobile: value)));
                        }
                      },
                      onChanged: (num){
                        if(num.length==10)
                        {
                          FocusScope.of(context).requestFocus(FocusNode());
                        }
                      },
                      cursorHeight: 30,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white)),
                        labelText: 'Enter Mobile',
                        labelStyle: TextStyle(
                            fontSize: MediaQuery.of(context).size.height / 70,
                            color: Colors.white),
                      ),
                    )),
                SizedBox(
                  height: 5.h,
                ),
                InkWell(
                  onTap: () {
                    if (getdata1() == true) {
                      f1.unfocus();
                      Navigator.push(context, Pageanimated(Otpverify()));
                    }
                  },
                  child: Container(
                    alignment: Alignment.center,
                    width: 60.w,
                    height: 6.h,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5), color: yellow),
                    child: Text(
                      'GET OTP',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: title,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                SizedBox(
                  height: 5.h,
                ),
                Container(
                  child: Row(
                    children: [
                      Expanded(
                          child: Container(
                        height: 1,
                        color: Colors.grey,
                      )),
                      SizedBox(
                        width: 10,
                      ),
                      Container(
                        child: Text(
                          'OR',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                          child: Container(
                        height: 1,
                        color: Colors.grey,
                      ))
                    ],
                  ),
                ),
                SizedBox(
                  height: 5.h,
                ),
                Container(
                  child: Text(
                    'Login with gmail or facebook?',
                    style: TextStyle(color: Colors.white, fontSize: 9.sp),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                          border: Border.all(color: Colors.white),
                          borderRadius: BorderRadius.circular(50)),
                      child: CircleAvatar(
                          backgroundColor: Colors.transparent,
                          child: Image.asset(
                            'assets/icons/google.png',
                            height: 3.h,
                          )),
                    ),
                    Container(
                      decoration: BoxDecoration(
                          border: Border.all(color: Colors.white),
                          borderRadius: BorderRadius.circular(50)),
                      child: CircleAvatar(
                          backgroundColor: Colors.transparent,
                          child: Image.asset(
                            'assets/icons/facebook.png',
                            height: 3.h,
                          )),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  getdata1() {
    final checkfrm2 = frmkey1.currentState.validate();
    if (!checkfrm2) {
      return true;
    }
    frmkey1.currentState.save();
    return false;
  }
}

// Verify otp in screen

class Otpverify extends StatefulWidget {
  String mobile;
  Otpverify({Key key, this.mobile}) : super(key: key);

  @override
  _OtpverifyState createState() => _OtpverifyState();
}

class _OtpverifyState extends State<Otpverify> {

  TextEditingController textEditingController = TextEditingController();
  // ignore: close_sinks
  StreamController<ErrorAnimationType> errorController;
  final formKey = GlobalKey<FormState>();
  String verify;
  bool hasError = false;
  String currentText = "";

  @override
  void initState() {
    errorController = StreamController<ErrorAnimationType>();
    super.initState();
  }

  @override
  void dispose() {
    errorController.close();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(10),
          height: 100.h,
          width: 100.h,
          decoration: BoxDecoration(
              color: Colors.black,
              image: DecorationImage(
                  image: AssetImage(
                    'assets/images/bg.jpg',
                  ),
                  colorFilter: new ColorFilter.mode(
                      Colors.black.withOpacity(0.3), BlendMode.dstATop),
                  fit: BoxFit.fill)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Bounce(
                preferences: AnimationPreferences(
                  autoPlay: AnimationPlayStates.Forward,
                  duration: Duration(milliseconds: 2000),
                ),
                child: Container(
                  child: Image.asset('assets/icons/png.png', height: 15.h),
                ),
              ),
              SizedBox(
                height: 1.h,
              ),
              Container(
                child: Text(
                  'OTP Verification',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 20.sp,
                      fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(
                height: 1.h,
              ),
              RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  text: 'Enter the OTP sent to',
                  style: TextStyle(fontSize: 11, fontFamily: 'VarelaRound'),
                  children: <TextSpan>[
                    TextSpan(
                        text: ' +91 - ${widget.mobile}',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontFamily: 'VarelaRound',
                            fontSize: 12)),
                    TextSpan(
                        text: '',
                        style:
                            TextStyle(fontFamily: 'VarelaRound', fontSize: 11)),
                  ],
                ),
              ),
              SizedBox(
                height: 5.h,
              ),
              Form(
                key: formKey,
                child: PinCodeTextField(
                  appContext: context,
                  pastedTextStyle: TextStyle(
                    color: yellow,
                  ),
                  textStyle: TextStyle(
                    color: yellow,
                    fontWeight: FontWeight.normal
                  ),
                  length: 6,
                  // obscureText: true,
                  // obscuringCharacter: '*',

                  blinkWhenObscuring: true,
                  animationType: AnimationType.fade,
                  pinTheme: PinTheme(
                    inactiveColor: Colors.grey, // without enter pin color
                    activeColor: yellow, //border color after enter pin
                    shape: PinCodeFieldShape.box,
                    selectedColor: yellow, //active border color
                    selectedFillColor: Colors.white, //active fill color
                    inactiveFillColor: Colors.grey,
                    borderRadius: BorderRadius.circular(5),
                    borderWidth: 1,
                    fieldHeight: 6.h,
                    fieldWidth: 12.w,
                    activeFillColor: Colors.grey, // after pin enter background
                  ),
                  cursorColor: yellow,
                  animationDuration: Duration(milliseconds: 300),
                  enableActiveFill: true,
                  errorAnimationController: errorController,
                  controller: textEditingController,
                  keyboardType: TextInputType.number,
                  // backgroundColor: Colors.red,

                  onCompleted: (v) {
                    print("rutvik$v");
                  },
                  onChanged: (value) {
                    print(value);
                    setState(() {
                      currentText = value;
                    });
                  },
                  beforeTextPaste: (text) {
                    print("Allowing to paste $text");
                    //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                    //but you can show anything you want here, like your pop up saying wrong paste format or etc
                    return true;
                  },
                ),
              ),
              SizedBox(
                height: 5.h,
              ),
              RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  text: 'Don\'t receive the OTP ? ',
                  style: TextStyle(fontSize: 11, fontFamily: 'VarelaRound'),
                  children: <TextSpan>[
                    TextSpan(
                        text: 'RESEND OTP',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontFamily: 'VarelaRound',
                            fontSize: 12,
                            color: yellow)),
                  ],
                ),
              ),
              SizedBox(
                height: 5.h,
              ),
              InkWell(
                onTap: () {
                  formKey.currentState.validate();
                  // conditions for validating
                  if (currentText.length != 6 || currentText != "123456") {
                    snackBar("OTP not match!", context);
                    errorController.add(ErrorAnimationType
                        .shake); // Triggering error shake animation
                    setState(() => hasError = true);
                  } else {
                    setState(
                      () {
                        hasError = false;
                        Navigator.push(context, Pageanimated(Bottombar()));    
                      },
                    );
                  }
                },
                child: Container(
                  alignment: Alignment.center,
                  width: 60.w,
                  height: 6.h,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5), color: yellow),
                  child: Text(
                    'VERIFY & PROCEED',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: title,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class Bottom extends StatefulWidget {
  Bottom({Key key}) : super(key: key);

  @override
  _BottomState createState() => _BottomState();
}

class _BottomState extends State<Bottom> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: TitledBottomNavigationBar(
          // currentIndex: 2,
          // Use this to update the Bar giving a position
          activeColor: yellow,
          onTap: (index) {
            print("Selected Index: $index");
          },
          items: [
            TitledNavigationBarItem(
                title: Text('Home',
                    style:
                        TextStyle(fontSize: text, fontWeight: FontWeight.w500)),
                icon: Icons.home),
            TitledNavigationBarItem(
                title: Text('Search',
                    style:
                        TextStyle(fontSize: text, fontWeight: FontWeight.w500)),
                icon: Icons.search),
            TitledNavigationBarItem(
                title: Text('Bag',
                    style:
                        TextStyle(fontSize: text, fontWeight: FontWeight.w500)),
                icon: Icons.card_travel),
            TitledNavigationBarItem(
                title: Text('Profile',
                    style:
                        TextStyle(fontSize: text, fontWeight: FontWeight.w500)),
                icon: Icons.person_outline),
          ]),
      body: Container(),
    );
  }
}
