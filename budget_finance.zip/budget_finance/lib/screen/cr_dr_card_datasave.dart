import 'package:budget_finance/globle.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_credit_card/credit_card_form.dart';
import 'package:flutter_credit_card/credit_card_model.dart';
import 'package:flutter_credit_card/flutter_credit_card.dart';
import 'package:folding_cell/folding_cell/widget.dart';
import 'package:sizer/sizer.dart';


// fetch new card data

class Cardsample extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return CardsampleState();
  }
}

class CardsampleState extends State<Cardsample> {
  String cardNumber = '';
  String expiryDate = '';
  String cardHolderName = '';
  String cvvCode = '';
  bool isCvvFocused = false;
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: Column(
          children: <Widget>[
            CreditCardWidget(
              cardNumber: cardNumber,
              expiryDate: expiryDate,
              cardHolderName: cardHolderName,
              cvvCode: cvvCode,
              showBackView: isCvvFocused,
              obscureCardNumber: true,
              obscureCardCvv: true,
              cardBgColor: yellow,
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    CreditCardForm(
                      formKey: formKey,
                      obscureCvv: true,
                      obscureNumber: true,
                      cardNumber: cardNumber,
                      cvvCode: cvvCode,
                      cardHolderName: cardHolderName,
                      expiryDate: expiryDate,
                      themeColor: Colors.blue,
                      cardNumberDecoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white)),
                        labelText: 'Number',
                        labelStyle: TextStyle(
                            fontSize: MediaQuery.of(context).size.height / 70,
                            color: Colors.black),
                        hintText: 'XXXX XXXX XXXX XXXX',
                        hintStyle: TextStyle(
                            fontSize: MediaQuery.of(context).size.height / 70,
                            color: Colors.black),
                      ),
                      expiryDateDecoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white)),
                        labelText: 'Expired Date',
                        labelStyle: TextStyle(
                            fontSize: MediaQuery.of(context).size.height / 70,
                            color: Colors.black),
                        hintText: 'XX/XX',
                        hintStyle: TextStyle(
                            fontSize: MediaQuery.of(context).size.height / 70,
                            color: Colors.black),
                      ),
                      cvvCodeDecoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white)),
                        labelText: 'CVV',
                        labelStyle: TextStyle(
                            fontSize: MediaQuery.of(context).size.height / 70,
                            color: Colors.black),
                        hintText: 'XXX',
                        hintStyle: TextStyle(
                            fontSize: MediaQuery.of(context).size.height / 70,
                            color: Colors.black),
                      ),
                      cardHolderDecoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: yellow),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white)),
                        labelText: 'Card Holder',
                        labelStyle: TextStyle(
                            fontSize: MediaQuery.of(context).size.height / 70,
                            color: Colors.black),
                      ),
                      onCreditCardModelChange: onCreditCardModelChange,
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        SizedBox(
                          width: 13
                        ),
                        Expanded(
                          child: InkWell(
                            onTap: () {
                            if (formKey.currentState.validate()) {
                              print('valid!');
                            } else {
                              print('invalid!');
                            }
                          },
                            child: expandedbtn("SUBMIT"),
                          )
                        ),
                        SizedBox(
                          width: 12
                        ),
                        Expanded(
                          child: InkWell(
                            onTap: (){},
                            child: expandedbtn('CANCLE'),
                          )
                        ),
                        SizedBox(
                          width: 13
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void onCreditCardModelChange(CreditCardModel creditCardModel) {
    setState(() {
      cardNumber = creditCardModel.cardNumber;
      expiryDate = creditCardModel.expiryDate;
      cardHolderName = creditCardModel.cardHolderName;
      cvvCode = creditCardModel.cvvCode;
      isCvvFocused = creditCardModel.isCvvFocused;
    });
  }
}


// flipcard

class FoldingCellSimpleDemo extends StatelessWidget {
  final _foldingCellKey = GlobalKey<SimpleFoldingCellState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.push(context, Pageanimated(Cardsample()));
          },
          child: CircleAvatar(
            backgroundColor: yellow,
            radius: 4.1.h,
            child: Icon(
              Icons.add,
              color: Colors.white,
              size: 4.h,
            ),
          ),
        ),
      body: Container(
        decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage('assets/images/corner.png'),
                  fit: BoxFit.cover,
                  alignment: Alignment.topCenter),
            ),
        child: Column(
          children: [
            SizedBox(
              height: .6+8.h,
            ),
            Container(
              // color: Color(0xffFCC139),
              alignment: Alignment.topCenter,
              child: SimpleFoldingCell.create(
                key: _foldingCellKey,
                frontWidget: _buildFrontWidget(), 
                innerWidget: _buildInnerWidget(),
                cellSize: Size(MediaQuery.of(context).size.width, 262),
                padding: EdgeInsets.all(15),
                animationDuration: Duration(milliseconds: 300),
                borderRadius: 10,
                onOpen: () => print('cell opened'),
                onClose: () => print('cell closed'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFrontWidget() {
    return Container(
      color: Colors.grey[50],
      alignment: Alignment.center,
      child: Stack(
        children: <Widget>[
          CreditCardWidget(
            cardNumber: "2440 1526 4332 3456",
            expiryDate: "2/22",
            cardHolderName: "Keval Bhuva",
            cvvCode: "***",
            showBackView: false,
            obscureCardNumber: false,
            obscureCardCvv: true,
          ),
          Positioned(
            right: 20,
            bottom: 20,
            child: TextButton(
              onPressed: () => _foldingCellKey?.currentState?.toggleFold(),
              child: Text(
                "Open",
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.w500
                ),
              ),
              style: TextButton.styleFrom(
                backgroundColor: Colors.white,
                minimumSize: Size(30, 15),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildInnerWidget() {
    return Column(
      children: [
        CreditCardWidget(
          cardNumber: "2440 1526 4332 3456",
          expiryDate: "2/22",
          cardHolderName: "Keval Bhuva",
          cvvCode: "***",
          showBackView: false,
          obscureCardNumber: false,
          obscureCardCvv: true,
        ),
        Container(
          color: Color(0xFFecf2f9),
          padding: EdgeInsets.only(top: 0),
          child: Stack(
            children: [
              CreditCardWidget(
                cardNumber: "2440152632",
                expiryDate: "2/22",
                cardHolderName: "cardHolderName",
                cvvCode: "223",
                showBackView: true,
                obscureCardNumber: true,
                obscureCardCvv: false,
              ),
              Positioned(
                left: 20,
                // right: 20,
                bottom: 20,
                child: TextButton(
                  onPressed: () => _foldingCellKey?.currentState?.toggleFold(),
                  child: Text(
                    "Close",
                    style: TextStyle(
                      color: Colors.black
                    ),
                  ),
                  style: TextButton.styleFrom(
                    backgroundColor: Colors.white,
                    minimumSize: Size(30, 15),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}


