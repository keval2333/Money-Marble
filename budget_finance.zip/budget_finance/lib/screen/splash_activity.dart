import 'dart:async';
import 'dart:ui';
import 'package:budget_finance/screen/loginotp_activity.dart';
import 'package:flutter_animator/flutter_animator.dart';
import 'package:flutter_animator/widgets/attention_seekers/bounce.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

class SecondClass extends StatefulWidget {
  @override
  _SecondClassState createState() => _SecondClassState();
}

class _SecondClassState extends State<SecondClass>
    with TickerProviderStateMixin {
  AnimationController scaleController;
  Animation<double> scaleAnimation;

  @override
  void initState() {
    super.initState();

    scaleController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 1500),
    )..addStatusListener(
        (status) {
          if (status == AnimationStatus.completed) {
            Navigator.of(context).pushReplacement(
              PageTransition(
                type: PageTransitionType.bottomToTop,
                child: Loginscreen(),
              ),
            );
            Timer(
              Duration(milliseconds: 300),
              () {
                scaleController.reset();
              },
            );
          }
        },
      );

    scaleAnimation =
        Tween<double>(begin: 0.0, end: 12).animate(scaleController);

    Timer(Duration(seconds: 2), () {
      setState(() {
        scaleController.forward();
      });
    });
  }

  @override
  void dispose() {
    // TODO: implement dispose
    scaleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          SizedBox(
            height: 40.h,
          ),
          Bounce(
            preferences: AnimationPreferences(autoPlay: AnimationPlayStates.Forward,duration: Duration(milliseconds: 2000),),
            child: Container(
              child: Image.asset('assets/icons/png.png',
              height: 13.h,),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          // Center(
          //   child: DefaultTextStyle(
          //     style: TextStyle(fontSize: 30.0),
          //     child: AnimatedTextKit(
          //       animatedTexts: [
          //         TyperAnimatedText(
          //           'Money Marble',
          //           textAlign: TextAlign.center,
          //           textStyle: TextStyle(
          //             letterSpacing: 0,
          //             color: Colors.white,
          //             fontFamily: 'VarelaRound',
          //           ),
          //           speed: Duration(milliseconds: 150),
          //         ),
          //       ],
          //       isRepeatingAnimation: false,
          //       repeatForever: false,
          //       displayFullTextOnTap: false,
          //     ),
          //   ),
          // ),
        
          SizedBox(
            height: 8,
          ),
          Container(
            child: Text("The Power Of Financial Management",
            style: TextStyle(
              color: Colors.grey,
              fontSize: 7.sp
            ))
          )
        ],
      ),
    );
  }
}

