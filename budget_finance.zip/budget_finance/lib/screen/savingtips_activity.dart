import 'package:budget_finance/globle.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:clipboard/clipboard.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animator/flutter_animator.dart';
import 'package:share/share.dart';
import 'package:sizer/sizer.dart';

// Tips List

class Tips extends StatefulWidget {
  const Tips({Key key}) : super(key: key);

  @override
  _TipsState createState() => _TipsState();
}

class _TipsState extends State<Tips> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          padding: EdgeInsets.fromLTRB(10, 15, 10, 5),
          child: Column(
            children: [
              headingtext('Saving Tips'),
              SizedBox(
                height: 5,
              ),
              Expanded(
                child: FadeInDownBig(
                  preferences: AnimationPreferences(
                    autoPlay: AnimationPlayStates.Forward,
                    duration: Duration(milliseconds: 1000),
                  ),
                  child: ListView.builder(
                      itemCount: 5,
                      itemBuilder: (context, index) {
                        return Container(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                  height:
                                      MediaQuery.of(context).size.height / 80),
                              InkWell(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => Tips_detail()));
                                },
                                child: Container(
                                  width: 110.w,
                                  height: 19.h,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(7),
                                      image: DecorationImage(
                                        image: AssetImage(
                                            "assets/images/saving_tips.jpg"),
                                        fit: BoxFit.cover,
                                      )),
                                  child: Container(
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(7),
                                        color: Colors.black.withOpacity(0.5)),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Container(
                                          child: Column(
                                            children: [
                                              SizedBox(
                                                  height: MediaQuery.of(context)
                                                          .size
                                                          .height /
                                                      55),
                                              Container(
                                                padding: EdgeInsets.fromLTRB(
                                                    15, 0, 15, 0),
                                                alignment: Alignment.centerLeft,
                                                child: Row(
                                                  children: [
                                                    Icon(
                                                      Icons.circle,
                                                      color: Colors.white,
                                                      size: 10,
                                                    ),
                                                    SizedBox(
                                                      width:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width /
                                                              70,
                                                    ),
                                                    Container(
                                                      width:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width /
                                                              1.3,
                                                      child: Text(
                                                        tipstitle[index],
                                                        maxLines: 1,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: TextStyle(
                                                            color: Colors.white,
                                                            fontSize: title),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          height: 7.h,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Container(
                                                alignment: Alignment.center,
                                                margin:
                                                    EdgeInsets.only(right: 10),
                                                decoration: BoxDecoration(
                                                    color: yellow,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5)),
                                                padding: EdgeInsets.fromLTRB(
                                                    10, 5, 10, 5),
                                                child: Text(
                                                  'View',
                                                  style: TextStyle(
                                                      fontSize: 10.sp),
                                                )),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      }),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Tipes detail

class Tips_detail extends StatefulWidget {
  const Tips_detail({Key key}) : super(key: key);

  @override
  _Tips_detailState createState() => _Tips_detailState();
}

class _Tips_detailState extends State<Tips_detail> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          body: Container(
        child: GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 1,
            mainAxisSpacing: 15,
            childAspectRatio: MediaQuery.of(context).size.width /
                (MediaQuery.of(context).size.height),
          ),
          itemCount: 1,
          itemBuilder: (context, index) {
            return Container(
              child: CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  SliverAppBar(
                    
                      pinned: true,
                      floating: true,
                      expandedHeight: 250.0,
                      flexibleSpace: Container(
                        decoration: BoxDecoration(
                          color: yellow,
                        ),
                        child: FlexibleSpaceBar(

                            titlePadding: EdgeInsets.all(10),
                            title: Text(
                              tipstitle[index],
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize:
                                    MediaQuery.of(context).size.height / 60.0,
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            centerTitle: true,
                            background: Image.asset(
                              "assets/images/saving_tips.jpg",
                              fit: BoxFit.cover,
                            )),
                      )),
                  SliverList(
                    delegate: SliverChildListDelegate([
                      Container(
                        padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                FloatingActionButton(
                                  onPressed: () {
                                    if ("Design and sell print-on-demand t-shirts"
                                            .trim() ==
                                        "") {
                                      print('enter text');
                                    } else {
                                      FlutterClipboard.copy(
                                              "Design and sell print-on-demand t-shirts")
                                          .then((value) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(SnackBar(
                                          content: Text("Copied"),
                                          action: SnackBarAction(
                                            label: 'Ok',
                                            onPressed: () {},
                                          ),
                                        ));
                                      });
                                    }
                                  },
                                  child: Icon(Icons.copy),
                                  backgroundColor: Colors.blue,
                                  foregroundColor: Colors.white,
                                ),
                                FloatingActionButton(
                                  onPressed: () {
                                    Share.share(
                                        "Design and sell print-on-demand t-shirts" +
                                            "\n\nDesign and sell print-on-demand t-shirts");
                                  },
                                  child: Icon(Icons.share),
                                  backgroundColor: Colors.green,
                                  foregroundColor: Colors.white,
                                )
                              ],
                            ),
                            SizedBox(
                                height:
                                    MediaQuery.of(context).size.height / 40),
                            Container(
                              child: Text(
                                tipsdesc[index],
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                    fontSize:
                                        MediaQuery.of(context).size.height /
                                            45),
                              ),
                            ),
                            SizedBox(
                              height: MediaQuery.of(context).size.height / 40,
                            ),
                          ],
                        ),
                      ),
                    ]),
                  ),
                ],
              ),
            );
          },
        ),
      )),
    );
  }
}
