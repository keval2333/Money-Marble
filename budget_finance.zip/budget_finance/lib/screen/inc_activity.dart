import 'dart:ui';
import 'package:budget_finance/globle.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:folding_cell/folding_cell/widget.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:sizer/sizer.dart';

// display income expence

class Expincdisplay extends StatefulWidget {
  Expincdisplay({Key key}) : super(key: key);

  @override
  _ExpincdisplayState createState() => _ExpincdisplayState();
}

class _ExpincdisplayState extends State<Expincdisplay> {
  var _foldingCellKey = GlobalKey<SimpleFoldingCellState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.push(context, Pageanimated(Expincfetch()));
          },
          child: CircleAvatar(
            backgroundColor: yellow,
            radius: 4.1.h,
            child: Icon(
              Icons.add,
              color: Colors.white,
              size: 4.h,
            ),
          ),
        ),
        body: Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/corner.png'),
                fit: BoxFit.cover,
                alignment: Alignment.topCenter),
          ),
          child: Column(
            children: [
              SizedBox(height: 30),
              SizedBox(height: 10),
              Container(
                padding: EdgeInsets.fromLTRB(10, 15, 10, 15),
                width: 100.w,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(7),
                    color: Colors.green[300]),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      width: 20.w,
                      padding: EdgeInsets.only(top:2,bottom:2),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10)
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        'INCOME',
                        style: TextStyle(
                          fontSize: 9.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.green
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Container(
                            width: 30.w,
                            child: Text(
                              'Reason',
                              style: TextStyle(
                                  fontSize: 10.sp,color: Colors.white,fontWeight: FontWeight.bold,),
                            )),
                        Expanded(
                            child: Text(
                          'Mayo pav',
                          style: TextStyle(fontSize: 10.sp,color: Colors.white,),
                        )),
                      ],
                    ),
                    Divider(color: Colors.white,),
                    Row(
                      children: [
                        Container(
                            width: 30.w,
                            child: Text(
                              'Amount',
                              style: TextStyle(
                                  fontSize: 10.sp, fontWeight: FontWeight.bold,color: Colors.white),
                            )),
                        Container(
                            child: Text(
                          '1200',
                          style: TextStyle(fontSize: 10.sp,color: Colors.white),
                        )),
                      ],
                    ),
                    Divider(color: Colors.white,),
                    Row(
                      children: [
                        Container(
                            width: 30.w,
                            child: Text(
                              'Date',
                              style: TextStyle(
                                  fontSize: 10.sp, fontWeight: FontWeight.bold,color: Colors.white),
                            )),
                        Container(
                            child: Text(
                          '24/03/2021',
                          style: TextStyle(fontSize: 10.sp,color: Colors.white),
                        )),
                      ],
                    ),
                    Divider(color: Colors.white,),
                    Row(
                      children: [
                        Container(
                            width: 30.w,
                            child: Text(
                              'Caption',
                              style: TextStyle(
                                  fontSize: 10.sp, fontWeight: FontWeight.bold,color: Colors.white),
                            )),
                        Expanded(
                            child: Text(
                          'Vada pav and buttermilk ',
                          style: TextStyle(fontSize: 10.sp,color: Colors.white),
                        )),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: 10),
              Container(
                padding: EdgeInsets.fromLTRB(10, 15, 10, 15),
                width: 100.w,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(7),
                    color: Colors.red[300]),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      width: 20.w,
                      padding: EdgeInsets.only(top:2,bottom:2),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10)
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        'EXPENCE',
                        style: TextStyle(
                          fontSize: 9.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.red
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Container(
                            width: 30.w,
                            child: Text(
                              'Reason',
                              style: TextStyle(
                                  fontSize: 10.sp,color: Colors.white,fontWeight: FontWeight.bold,),
                            )),
                        Expanded(
                            child: Text(
                          'Mayo pav',
                          style: TextStyle(fontSize: 10.sp,color: Colors.white,),
                        )),
                      ],
                    ),
                    Divider(color: Colors.white,),
                    Row(
                      children: [
                        Container(
                            width: 30.w,
                            child: Text(
                              'Amount',
                              style: TextStyle(
                                  fontSize: 10.sp, fontWeight: FontWeight.bold,color: Colors.white),
                            )),
                        Container(
                            child: Text(
                          '1200',
                          style: TextStyle(fontSize: 10.sp,color: Colors.white),
                        )),
                      ],
                    ),
                    Divider(color: Colors.white,),
                    Row(
                      children: [
                        Container(
                            width: 30.w,
                            child: Text(
                              'Date',
                              style: TextStyle(
                                  fontSize: 10.sp, fontWeight: FontWeight.bold,color: Colors.white),
                            )),
                        Container(
                            child: Text(
                          '24/03/2021',
                          style: TextStyle(fontSize: 10.sp,color: Colors.white),
                        )),
                      ],
                    ),
                    Divider(color: Colors.white,),
                    Row(
                      children: [
                        Container(
                            width: 30.w,
                            child: Text(
                              'Caption',
                              style: TextStyle(
                                  fontSize: 10.sp, fontWeight: FontWeight.bold,color: Colors.white),
                            )),
                        Expanded(
                            child: Text(
                          'Vada pav and buttermilk ',
                          style: TextStyle(fontSize: 10.sp,color: Colors.white),
                        )),
                      ],
                    ),
                  ],
                ),
              ),
              ],
          ),
        ));
  }

  filter(context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return Container(
            height: 50.h,
          );
        });
  }
}


// fetch income expence

class Expincfetch extends StatefulWidget {
  Expincfetch({Key key}) : super(key: key);

  @override
  _ExpincfetchState createState() => _ExpincfetchState();
}

class _ExpincfetchState extends State<Expincfetch> {
  var frmkey1 = GlobalKey<FormState>();
  String _chosenValue;
  TextEditingController bankname = new TextEditingController();
  TextEditingController accountnumber = new TextEditingController();
  DateTime dt = DateTime.now();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/images/corner.png'),
              fit: BoxFit.cover,
              alignment: Alignment.topCenter),
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.all(10),
          child: Form(
            key: frmkey1,
            child: Column(
              children: [
                SizedBox(
                  height: 6.h,
                ),
                headingtext('Expence Income Transection'),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  padding:
                      EdgeInsets.only(left: 5, top: 13, bottom: 13, right: 5),
                  width: 100.h,
                  decoration: BoxDecoration(
                      border: Border.all(color: yellow),
                      borderRadius: BorderRadius.circular(5)),
                  child: DropdownButtonFormField<String>(
                    isExpanded: true,
                    focusColor: Colors.white,
                    decoration: InputDecoration.collapsed(hintText: ''),
                    value: _chosenValue,
                    //elevation: 5,
                    style: TextStyle(color: Colors.white),
                    iconEnabledColor: Colors.black,
                    items: <String>[
                      'Expence',
                      'Income',
                    ].map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Container(
                          width: 80.w,
                          child: Text(
                            value,
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                      );
                    }).toList(),
                    hint: Text(
                      "--Select--",
                      style: TextStyle(color: Colors.black, fontSize: 10.sp),
                    ),
                    onChanged: (String value) {
                      setState(() {
                        _chosenValue = value;
                      });
                    },
                  ),
                ),
                SizedBox(
                  height: 4.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: bankname,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter reason", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter reason',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                Container(
                  alignment: Alignment.center,
                  child: InkWell(
                    onTap: () {
                      selectdate(context);
                    },
                    child: Container(
                        padding: EdgeInsets.fromLTRB(10, 18, 0, 18),
                        alignment: Alignment.topLeft,
                        width: 100.w,
                        decoration: BoxDecoration(
                            border: Border.all(color: yellow, width: 1),
                            borderRadius: BorderRadius.circular(5)),
                        child: Text("${dt.day}-${dt.month}-${dt.year}",
                            textAlign: TextAlign.left,
                            style: TextStyle(fontSize: text))),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                TextFormField(
                  cursorColor: yellow,
                  controller: bankname,
                  keyboardType: TextInputType.text,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: text,
                  ),
                  //ignore: missing_return
                  validator: (value) {
                    if (value.isEmpty) {
                      return snackBar("Enter caption", context);
                    } else {}
                  },
                  cursorHeight: 30,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: yellow),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: yellow)),
                    labelText: 'Enter caption',
                    labelStyle: TextStyle(
                        fontSize: MediaQuery.of(context).size.height / 70,
                        color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                        child: InkWell(
                      onTap: () {},
                      child: expandedbtn("SUBMIT"),
                    )),
                    SizedBox(width: 10),
                    Expanded(
                        child: InkWell(
                      onTap: () {},
                      child: expandedbtn('CANCLE'),
                    )),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  selectdate(BuildContext context) async {
    final DateTime pick = await showDatePicker(
      context: context,
      initialDate: dt,
      firstDate: DateTime(1800),
      lastDate: DateTime.now(),
      initialEntryMode: DatePickerEntryMode.calendarOnly,
      helpText: 'Select Exp/Inc Date',
      cancelText: 'Cancle',
      confirmText: 'Ok',
      errorFormatText: 'Error',
      errorInvalidText: 'Wrong',
      fieldHintText: 'Select date',
      fieldLabelText: 'Enter Date',
    );
    if (pick != null && pick != dt) {
      setState(() {
        dt = pick;
      });
    }
  }
}
