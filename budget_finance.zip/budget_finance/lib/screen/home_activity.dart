import 'package:budget_finance/globle.dart';
import 'package:budget_finance/ruff.dart';
import 'package:budget_finance/screen/bankdetail_activity.dart';
import 'package:budget_finance/screen/calculator/Interestcalculation_activity.dart';
import 'package:budget_finance/screen/calculator/agecalculation_activity.dart';
import 'package:budget_finance/screen/calculator/color_provider.dart';
import 'package:budget_finance/screen/calculator/main.dart';
import 'package:budget_finance/screen/calculator/unitcalculation_activity.dart';
import 'package:budget_finance/screen/cr_dr_card_datasave.dart';
import 'package:budget_finance/screen/inc_activity.dart';
import 'package:budget_finance/screen/loandetail_activity.dart';
import 'package:budget_finance/screen/manage_dr_cr_card_activity.dart';
import 'package:budget_finance/screen/managebills_activity.dart';
import 'package:budget_finance/screen/profile_activity.dart';
import 'package:budget_finance/screen/savingtips_activity.dart';
import 'package:budget_finance/screen/soldiery_activity.dart';
import 'package:budget_finance/widget/widget.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hive/hive.dart';
import 'package:sizer/sizer.dart';

class Home extends StatefulWidget {
  Home({Key key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  void initState() {
    super.initState();
    yellow = Color(int.parse(changecolor()));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Scaffold(
        backgroundColor: Colors.white,
        drawer: Changecolor(),
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Builder(
            builder: (context) => InkWell(
              child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: FaIcon(FontAwesomeIcons.bars)),
              onTap: () => Scaffold.of(context).openDrawer(),
            ),
          ),
          backgroundColor: yellow,
          elevation: 0,
          centerTitle: false,
          titleSpacing: 0,
        ),
        body: SingleChildScrollView(
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                  decoration: BoxDecoration(
                      color: yellow,
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(50),
                          bottomRight: Radius.circular(50))),
                  child: Column(
                    children: [
                      Container(
                        child: Container(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Hi, Keval',
                            style: TextStyle(
                                fontSize: text, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      SizedBox(height: 1.h),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Text(
                              'Manage Your \nDaily Transection',
                              style: TextStyle(
                                fontSize: heading,
                                height: 1.4,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              Navigator.push(context, Pageanimated(Profile()));
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                  border: Border.all(color: Colors.black),
                                  borderRadius: BorderRadius.circular(50)),
                              child: CircleAvatar(
                                radius: 3.5.h,
                                child: Image.asset('assets/images/man.png'),
                              ),
                            ),
                          )
                        ],
                      ),
                      SizedBox(height: 4.h),
                      Row(
                        children: [
                          Container(
                            child: Text(
                              'Manage',
                              style: TextStyle(
                                  fontSize: text, fontWeight: FontWeight.w900),
                            ),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Container(
                            height: 1,
                            width: 10.h,
                            color: Colors.black,
                          )
                        ],
                      ),
                      SizedBox(height: 2.h),
                      Container(
                        child: Column(
                          children: [
                            Container(
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(
                                          context, Pageanimated(Billdisplay()));
                                    },
                                    child: Column(
                                      children: [
                                        CircleAvatar(
                                            radius: 3.5.h,
                                            backgroundColor: Colors.white,
                                            child: Image.asset(
                                              'assets/icons/bill.png',
                                              height: 3.5.h,
                                            )),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          'Manage\nBills',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(fontSize: 9.sp),
                                        ),
                                      ],
                                    ),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(context,
                                          Pageanimated(Displaysoldieryname()));
                                    },
                                    child: Column(
                                      children: [
                                        CircleAvatar(
                                            radius: 3.5.h,
                                            backgroundColor: Colors.white,
                                            child: Image.asset(
                                              'assets/icons/soldiery.png',
                                              height: 4.h,
                                            )),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          'Manage\nSoldiery',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(fontSize: 9.sp),
                                        ),
                                      ],
                                    ),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(context,
                                          Pageanimated(Expincdisplay()));
                                    },
                                    child: Column(
                                      children: [
                                        CircleAvatar(
                                            radius: 3.5.h,
                                            backgroundColor: Colors.white,
                                            child: Image.asset(
                                              'assets/icons/exp.inc.png',
                                              height: 4.h,
                                            )),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          'Expence\nIncome',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(fontSize: 9.sp),
                                        ),
                                      ],
                                    ),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(
                                          context,
                                          Pageanimated(
                                              FoldingCellSimpleDemo()));
                                    },
                                    child: Column(
                                      children: [
                                        CircleAvatar(
                                            radius: 3.5.h,
                                            backgroundColor: Colors.white,
                                            child: Image.asset(
                                              'assets/icons/crdrcard.png',
                                              height: 4.h,
                                            )),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          'Cr./Dr.\nCard',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(fontSize: 9.sp),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 3.h,
                            ),
                            Container(
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(context,
                                          Pageanimated(Bankdetaildisplay()));
                                    },
                                    child: Column(
                                      children: [
                                        CircleAvatar(
                                            radius: 3.5.h,
                                            backgroundColor: Colors.white,
                                            child: Image.asset(
                                              'assets/icons/bank.png',
                                              height: 4.h,
                                            )),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          'Bank\nDetail',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(fontSize: 9.sp),
                                        ),
                                      ],
                                    ),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(context,
                                          Pageanimated(Loandetaildisplay()));
                                    },
                                    child: Column(
                                      children: [
                                        CircleAvatar(
                                            radius: 3.5.h,
                                            backgroundColor: Colors.white,
                                            child: Image.asset(
                                              'assets/icons/loan.png',
                                              height: 4.h,
                                            )),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          'Loan\nDetail',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(fontSize: 9.sp),
                                        ),
                                      ],
                                    ),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(
                                          context, Pageanimated(Tips()));
                                    },
                                    child: Column(
                                      children: [
                                        CircleAvatar(
                                            radius: 3.5.h,
                                            backgroundColor: Colors.white,
                                            child: Image.asset(
                                              'assets/icons/saving.png',
                                              height: 4.h,
                                            )),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          'Saving\nTips',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(fontSize: 9.sp),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 3.h),
                    ],
                  ),
                ),
                SizedBox(height: 2.h),
                Stack(
                  children: [
                    Container(
                      height: 28.h,
                      width: 100.w,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage('assets/images/corner.png'),
                            fit: BoxFit.cover,
                            alignment: Alignment.topCenter),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Container(
                                child: Text(
                                  'Daily Calculation',
                                  style: TextStyle(
                                      fontSize: text,
                                      fontWeight: FontWeight.w900),
                                ),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Container(
                                height: 1,
                                width: 10.h,
                                color: Colors.black,
                              )
                            ],
                          ),
                          SizedBox(height: 2.h),
                          Container(
                            height: 20.h,
                            width: 100.w,
                            child: ListView(
                              scrollDirection: Axis.horizontal,
                              children: [
                                InkWell(
                                  onTap: () async {
                                    final box = await Hive.openBox(boxColor);
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => MyApp()));
                                  },
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(7, 10, 7, 5),
                                    // height: 25.h,
                                    width: 25.w,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      color: Colors.grey[50],
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color.fromRGBO(0, 0, 0, 1.0),
                                          offset: Offset(0.1, 0.1),
                                          blurRadius: 0,
                                          spreadRadius: 0,
                                        )
                                      ],
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          child: Image.asset(
                                            'assets/icons/simplecal.png',
                                            height: 7.h,
                                          ),
                                        ),
                                        Container(
                                          child: Text(
                                            'Simple Calculation',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: text),
                                          ),
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            SizedBox(),
                                            Container(
                                              child: InkWell(
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                      color: yellow,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              3)),
                                                  padding: EdgeInsets.fromLTRB(
                                                      5, 3, 5, 3),
                                                  child: Text(
                                                    'Start',
                                                    style: TextStyle(
                                                        fontSize: 7.sp),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 20,
                                ),
                                InkWell(
                                  onTap: () {
                                    Navigator.push(context,
                                        Pageanimated(Interestcalculation()));
                                  },
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(7, 10, 7, 5),
                                    height: 25.h,
                                    width: 25.w,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      color: yellow,
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color.fromRGBO(0, 0, 0, 1.0),
                                          offset: Offset(0.1, 0.1),
                                          blurRadius: 0,
                                          spreadRadius: 0,
                                        )
                                      ],
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          child: Image.asset(
                                            'assets/icons/interestcal.png',
                                            height: 7.h,
                                          ),
                                        ),
                                        Container(
                                          child: Text(
                                            'Interest Calculation',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: text),
                                          ),
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            SizedBox(),
                                            Container(
                                              child: InkWell(
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                      color: Colors.white,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              3)),
                                                  padding: EdgeInsets.fromLTRB(
                                                      5, 3, 5, 3),
                                                  child: Text(
                                                    'Start',
                                                    style: TextStyle(
                                                        fontSize: 7.sp),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 20,
                                ),
                                InkWell(
                                  onTap: () {
                                    Navigator.push(context,
                                        Pageanimated(Agecalculation()));
                                  },
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(7, 10, 7, 5),
                                    height: 25.h,
                                    width: 25.w,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      color: Colors.grey[50],
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color.fromRGBO(0, 0, 0, 1.0),
                                          offset: Offset(0.1, 0.1),
                                          blurRadius: 0,
                                          spreadRadius: 0,
                                        )
                                      ],
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          child: Image.asset(
                                            'assets/icons/agecal.png',
                                            height: 7.h,
                                          ),
                                        ),
                                        Container(
                                          child: Text(
                                            'Age Calculation',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: text),
                                          ),
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            SizedBox(),
                                            Container(
                                              child: InkWell(
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                      color: yellow,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              3)),
                                                  padding: EdgeInsets.fromLTRB(
                                                      5, 3, 5, 3),
                                                  child: Text(
                                                    'Start',
                                                    style: TextStyle(
                                                        fontSize: 7.sp),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 20,
                                ),
                                InkWell(
                                  onTap: () {
                                    Navigator.push(context,
                                        Pageanimated(Unitcalculation()));
                                  },
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(7, 10, 7, 5),
                                    height: 25.h,
                                    width: 25.w,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      color: yellow,
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color.fromRGBO(0, 0, 0, 1.0),
                                          offset: Offset(0.1, 0.1),
                                          blurRadius: 0,
                                          spreadRadius: 0,
                                        )
                                      ],
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                          child: Image.asset(
                                            'assets/icons/unitconverter.png',
                                            height: 7.h,
                                          ),
                                        ),
                                        Container(
                                          child: Text(
                                            'Unit\nConverter',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: text),
                                          ),
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            SizedBox(),
                                            Container(
                                              child: InkWell(
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                      color: Colors.grey[50],
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              3)),
                                                  padding: EdgeInsets.fromLTRB(
                                                      5, 3, 5, 3),
                                                  child: Text(
                                                    'Start',
                                                    style: TextStyle(
                                                        fontSize: 7.sp),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 1.h),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
