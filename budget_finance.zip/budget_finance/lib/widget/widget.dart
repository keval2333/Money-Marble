import 'package:budget_finance/globle.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

// snak bar
snackBar(String message, context) {
  return ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      backgroundColor: Colors.redAccent,
      content: Text(
        message,
        style: TextStyle(color: Colors.white, fontSize: text),
      ),
      duration: Duration(seconds: 2),
    ),
  );
}

// Navigate screen animation

class Pageanimated extends PageRouteBuilder {
  final Widget page;

  Pageanimated(this.page)
      : super(
          pageBuilder: (context, animation, anotherAnimation) => page,
          transitionDuration: Duration(milliseconds: 2000), // 1000
          reverseTransitionDuration: Duration(milliseconds: 400), // 200
          transitionsBuilder: (context, animation, anotherAnimation, child) {
            animation = CurvedAnimation(
                curve: Curves.fastLinearToSlowEaseIn,
                parent: animation,
                reverseCurve: Curves.fastOutSlowIn);
            return Align(
              alignment: Alignment.centerRight,
              child: SizeTransition(
                axis: Axis.horizontal,
                sizeFactor: animation,
                child: page,
                axisAlignment: 0,
              ),
            );
          },
        );
}

// Drawer design

class Mydrawer extends StatefulWidget {
  Mydrawer({Key key}) : super(key: key);

  @override
  _MydrawerState createState() => _MydrawerState();
}

class _MydrawerState extends State<Mydrawer> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: Container(
      color: Colors.pinkAccent,
    ));
  }
}

//Long btn

longbtn(text) {
  return Container(
    alignment: Alignment.center,
    width: 60.w,
    height: 6.h,
    decoration:
        BoxDecoration(borderRadius: BorderRadius.circular(5), color: yellow),
    child: Text(
      text,
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.black, fontSize: title),
    ),
  );
}

// short btn

shortbtn(text) {
  return Container(
    alignment: Alignment.center,
    width: 30.w,
    height: 6.h,
    decoration:
        BoxDecoration(borderRadius: BorderRadius.circular(5), color: yellow),
    child: Text(
      text,
      textAlign: TextAlign.center,
      style: TextStyle(
        color: Colors.black,
        fontSize: title,
      ),
    ),
  );
}

// short btn white

shortbtncard(text) {
  return Container(
    alignment: Alignment.center,
    width: 20.w,
    height: 4.5.h,
    decoration:
        BoxDecoration(borderRadius: BorderRadius.circular(5), color: yellow),
    child: Text(
      text,
      textAlign: TextAlign.center,
      style: TextStyle(
        color: Colors.black,
        fontSize: 10.sp,
      ),
    ),
  );
}

// short btn white cars

shortbtncardwhite(text) {
  return Container(
    alignment: Alignment.center,
    width: 22.w,
    height: 5.h,
    decoration:
        BoxDecoration(borderRadius: BorderRadius.circular(5), color: Colors.white),
    child: Text(
      text,
      textAlign: TextAlign.center,
      style: TextStyle(
        color: Colors.black,
        fontSize: title,
      ),
    ),
  );
}

// expanded btn

expandedbtn(text) {
  return Container(
    alignment: Alignment.center,
    height: 6.h,
    decoration:
        BoxDecoration(borderRadius: BorderRadius.circular(5), color: yellow),
    child: Text(
      text,
      textAlign: TextAlign.center,
      style: TextStyle(
        color: Colors.black,
        fontSize: title,
      ),
    ),
  );
}

// heading

headingtext(text1) {
  return Row(
    children: [
      Container(
        child: Text(
          text1,
          style: TextStyle(fontSize: text, fontWeight: FontWeight.w900),
        ),
      ),
      SizedBox(
        width: 5,
      ),
      Container(
        height: 1,
        width: 10.h,
        color: Colors.black,
      )
    ],
  );
}

// age calculation for year,month,weak,day,hours,minutes

agebtn(text1,diff) {
  return Expanded(
      child: Container(
      alignment: Alignment.center,
      height: 15.h,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(5),
      color: Colors.grey[200] 
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          child: Text(
            diff,
            style: TextStyle(
              fontSize: 18.sp,
              fontWeight: FontWeight.bold
            ),
          ),
        ),
        SizedBox(
          height: 3,
        ),
        Container(
          child: Text(
            text1,
            style: TextStyle(fontSize: text),
          ),
        ),
      ],
    ),
  ));
}

callength(text1,diff) {
  return Expanded(
      child: Container(
        padding: EdgeInsets.all(5.0),
      alignment: Alignment.center,
      height: 15.h,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(5),
      color: Colors.grey[200] 
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          child: Text(
            diff,
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.bold
            ),
          ),
        ),
        SizedBox(
          height: 3,
        ),
        Container(
          child: Text(
            text1,
            style: TextStyle(fontSize: text),
          ),
        ),
      ],
    ),
  ));
}
